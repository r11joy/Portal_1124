# Portal

One voice assistant over your college portal, Gmail, Classroom and shared notes, built on MCP.
**New here? Read `LEARN.md` first.** It explains every file with school analogies.

## What exists (all tested)

| Piece | Where | Status |
|---|---|---|
| Fake college site + Playwright scraper (adapter) | `mock_portal/`, `portal_core/adapters.py` | done. Person A makes the real-college adapter |
| Portal MCP server | `servers/portal_server.py` | done: attendance, timetable, marks, `can_i_skip`, `cgpa_target_plan` |
| Calculators | `portal_core/calc.py` | done, unit tested |
| Notes MCP server | `servers/memory_server.py` | done: `save_note`, `list_notes`, `search_notes`, `get_note` (keyword search, local folder) |
| Classroom MCP server | `servers/classroom_server.py` | **stand-in with fake data**. Person B replaces the data part, keeps the tools |
| Gmail MCP server | `servers/gmail_server.py` | **stand-in with fake data**. Person B replaces the data part |
| Agent (MCP client + brain loop) | `agent/` | done and tested with a pretend brain. Real Claude test: `scripts/test_bedrock.py` (Person C) |

| Web page + server | `web/` | done: chat, mic (browser speech), "read aloud", MCP trace panel, PDF share, morning-briefing button |
| Demo brain | `agent/demo_llm.py` | done: offline pretend Claude so the page works without AWS. It only knows a few question types |

Also done: `find_deadline_clashes` (Classroom server, logic in `portal_core/clash.py`) and `scripts/run_demo.py` (one command starts everything).

Not built yet: ElevenLabs voice (a hook is marked in `web/static/index.html`), S3 storage, ChromaDB, the 7 AM scheduler, deployment files.

## See it in your browser (no AWS needed)

```bash
python scripts/run_demo.py     # easiest: starts both, then open http://127.0.0.1:8000

# or by hand:
python -m mock_portal.app      # terminal 1: the fake college site
python -m web.app              # terminal 2: Portal  ->  open http://127.0.0.1:8000
```

The badge at the top right says which brain is answering. Set `BEDROCK_MODEL_ID` (and `AWS_REGION`) before starting
`web.app` and it uses the real Claude instead. Set `PORTAL_BRAIN=demo` to force the demo brain.

## Run the checks

```bash
pip install -r requirements.txt
playwright install chromium            # one time
python -m pytest -q                    # 28 quick unit tests
python scripts/smoke_test.py           # portal server through a real MCP client
python scripts/agent_smoke_test.py     # whole system with a pretend brain (no AWS needed)
python scripts/web_smoke_test.py       # opens the web page in a real headless browser and uses it
```

## Test Bedrock (Person C, after Step 1)

```bash
python scripts/test_bedrock.py         # needs AWS_REGION + BEDROCK_MODEL_ID set, boto3, aws configure
python -m agent.cli                    # then chat with the real thing
```

## Who changes what

- **Person A:** `portal_core/adapters.py`. Copy `MockERPAdapter`, point it at the real site, register it in `build_adapter()`. Env vars: `PORTAL_ADAPTER`, `PORTAL_URL`, `PORTAL_USER`, `PORTAL_PASS`.
- **Person B:** only the `DATA SOURCE` block in `servers/classroom_server.py` and `servers/gmail_server.py`. Tool names and the returned shapes are written at the top of each file. Do not change them.
- **Person C:** `agent/` and `scripts/test_bedrock.py`. Add any new server to `agent/config.py`.
- **Person D:** `web/static/index.html` (the look) and `speak()` inside it (swap the browser voice for ElevenLabs). The server is `web/app.py`; the page talks to `/api/ask`, `/api/briefing`, `/api/upload`.

## Rules the code follows

- The LLM never does math. Tools do.
- Every answer carries `source`, `synced_at`, `stale`.
- Anything written by other people (emails, Classroom, notes) is labelled `content_trust: "untrusted"` and wrapped in `<untrusted_data>` before the brain sees it.
- Read-only. No tool writes to any account.
- Credentials come from environment variables, never from code. `.env` is git-ignored.

## Assumptions to confirm (top of `portal_core/calc.py`)

75% attendance; two internals of 25 each; VTU-style grade bands. Check your college's real scheme.

## Known limits

- Notes search is keyword counting, not meaning-based. Fine for the demo; ChromaDB can replace `NoteStore.search`.
- Scanned (photo) PDFs have no text and are rejected with a clear message. OCR isn't built.
- The agent keeps chat history in memory only.
