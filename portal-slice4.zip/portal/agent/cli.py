"""Talk to Portal in the terminal.

    set BEDROCK_MODEL_ID=...      (Windows)   /   export BEDROCK_MODEL_ID=...   (Mac/Linux)
    set AWS_REGION=...
    python -m agent.cli
"""
import asyncio
import logging
import sys

from .core import PortalAgent
from .llm import BedrockLLM


async def main() -> None:
    logging.basicConfig(level=logging.WARNING)
    try:
        llm = BedrockLLM()
    except Exception as exc:
        sys.exit(f"Can't start the brain: {exc}\nSee README -> 'Test Bedrock'.")
    async with PortalAgent(llm) as agent:
        print(f"Portal ready. Tools: {len(agent.tools)}.", end=" ")
        if agent.unavailable:
            print(f"(unavailable: {', '.join(agent.unavailable)})", end="")
        print("\nAsk anything, or type 'quit'.\n")
        while True:
            try:
                q = input("you> ").strip()
            except (EOFError, KeyboardInterrupt):
                break
            if q.lower() in ("quit", "exit"):
                break
            if not q:
                continue
            res = await agent.ask(q)
            print(f"\nportal> {res.answer}\n")
            for t in res.trace:
                print(f"   [{t['server']}] {t['tool']}  {t['ms']} ms  {'ok' if t['ok'] else 'FAILED'}")
            print()


if __name__ == "__main__":
    asyncio.run(main())
