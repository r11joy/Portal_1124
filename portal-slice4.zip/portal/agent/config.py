"""Which MCP servers the agent connects to. Add a line here to give Portal a new ability.

Each server is started as a child process and spoken to over stdio (nothing is exposed to the network).
Set PORTAL_SERVERS="portal,notes" to run only some (handy when one is broken).
"""
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

SERVERS = {
    "portal":    "servers.portal_server",     # attendance, marks, timetable, can_i_skip, cgpa_target_plan
    "classroom": "servers.classroom_server",  # assignments, announcements, materials
    "gmail":     "servers.gmail_server",      # search_emails, get_email
    "notes":     "servers.memory_server",     # save_note, list_notes, search_notes, get_note
}


def selected_servers() -> dict[str, str]:
    wanted = os.environ.get("PORTAL_SERVERS")
    if not wanted:
        return dict(SERVERS)
    names = [n.strip() for n in wanted.split(",") if n.strip()]
    return {n: SERVERS[n] for n in names if n in SERVERS}


def child_env() -> dict:
    """Environment for server processes: ours, plus the project on the import path."""
    return {**os.environ, "PYTHONPATH": str(ROOT)}


PYTHON = sys.executable
