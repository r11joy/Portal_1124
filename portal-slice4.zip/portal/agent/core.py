"""The agent: connects to every MCP server, lets the brain (an LLM) pick tools, runs them in parallel, repeats.

    async with PortalAgent(llm) as agent:
        result = await agent.ask("Can I skip tomorrow?")
        print(result.answer)      # the final reply
        print(result.trace)       # which tools ran, when, how long (for the on-screen "MCP proof" panel)
"""
from __future__ import annotations

import asyncio
import json
import logging
import time
from contextlib import AsyncExitStack
from dataclasses import dataclass, field
from typing import Optional

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

from . import config
from .llm import LLM
from .prompt import system_prompt

log = logging.getLogger("portal-agent")
MAX_TOOL_RESULT_CHARS = 12000


@dataclass
class AskResult:
    answer: str
    trace: list[dict] = field(default_factory=list)
    steps: int = 0


def _wrap_untrusted(text: str) -> str:
    """Emails, Classroom posts and notes are written by other people. Label them as DATA before the brain sees them."""
    try:
        blob = json.loads(text)
    except (ValueError, TypeError):
        return text
    if isinstance(blob, dict) and blob.get("content_trust") == "untrusted":
        safe = text.replace("</untrusted_data>", "[/untrusted_data]")  # content must not be able to close its own label
        return f"<untrusted_data>\n{safe}\n</untrusted_data>"
    return text


class PortalAgent:
    def __init__(self, llm: LLM, servers: Optional[dict[str, str]] = None, max_steps: int = 8):
        self.llm, self.servers, self.max_steps = llm, servers or config.selected_servers(), max_steps
        self.sessions: dict[str, ClientSession] = {}     # tool name -> the session that owns it
        self.tool_server: dict[str, str] = {}            # tool name -> server name (for the trace)
        self.tools: list[dict] = []
        self.unavailable: dict[str, str] = {}            # server name -> why it didn't start
        self.history: list[dict] = []
        self._stack = AsyncExitStack()

    # ------------------------------------------------------------------ start / stop
    async def __aenter__(self):
        await self._stack.__aenter__()
        for name, module in self.servers.items():
            try:
                params = StdioServerParameters(command=config.PYTHON, args=["-m", module], cwd=str(config.ROOT), env=config.child_env())
                read, write = await self._stack.enter_async_context(stdio_client(params))
                session = await self._stack.enter_async_context(ClientSession(read, write))
                await asyncio.wait_for(session.initialize(), timeout=30)
                for t in (await session.list_tools()).tools:
                    # SDK v1 calls this inputSchema, v2 calls it input_schema
                    schema = dict(getattr(t, "inputSchema", None) or getattr(t, "input_schema", None) or {})
                    schema.setdefault("type", "object")
                    self.sessions[t.name] = session
                    self.tool_server[t.name] = name
                    self.tools.append({"name": t.name, "description": t.description or "", "input_schema": schema})
            except Exception as exc:  # one broken server must not take Portal down
                log.warning("server %s unavailable: %r", name, exc)
                self.unavailable[name] = repr(exc)
        return self

    async def __aexit__(self, *exc):
        return await self._stack.__aexit__(*exc)

    def reset(self) -> None:
        self.history = []

    # ------------------------------------------------------------------ one tool call
    async def _call(self, block: dict, step: int, t0: float) -> tuple[dict, dict]:
        use = block["toolUse"]
        name, args = use["name"], use.get("input") or {}
        entry = {"step": step, "tool": name, "server": self.tool_server.get(name, "?"), "args": args,
                 "started_ms": round((time.perf_counter() - t0) * 1000)}
        started = time.perf_counter()
        try:
            if name not in self.sessions:
                raise LookupError(f"Unknown tool {name!r}")
            res = await asyncio.wait_for(self.sessions[name].call_tool(name, args), timeout=60)
            text = "".join(getattr(c, "text", "") for c in res.content)[:MAX_TOOL_RESULT_CHARS]
            ok = not (getattr(res, "isError", False) or getattr(res, "is_error", False))
        except Exception as exc:  # noqa: BLE001  tell the brain what went wrong instead of crashing
            text, ok = f"Tool failed: {exc}", False
        entry.update(ok=ok, ms=round((time.perf_counter() - started) * 1000))
        result_block = {"toolResult": {"toolUseId": use["toolUseId"], "content": [{"text": _wrap_untrusted(text)}],
                                       "status": "success" if ok else "error"}}
        return result_block, entry

    # ------------------------------------------------------------------ ask
    async def ask(self, question: str) -> AskResult:
        t0 = time.perf_counter()
        messages = self.history + [{"role": "user", "content": [{"text": question}]}]
        trace: list[dict] = []
        for step in range(1, self.max_steps + 1):
            out = await self.llm.generate(system_prompt(), messages, self.tools)
            msg = out["message"]
            messages.append(msg)
            calls = [b for b in msg["content"] if "toolUse" in b]
            if out["stop_reason"] != "tool_use" or not calls:
                self.history = messages
                text = "".join(b.get("text", "") for b in msg["content"]).strip()
                return AskResult(text, trace, step)
            results = await asyncio.gather(*(self._call(b, step, t0) for b in calls))  # all at once
            trace.extend(entry for _, entry in results)
            messages.append({"role": "user", "content": [block for block, _ in results]})
        self.history = messages
        return AskResult("Sorry, that took too many steps and I couldn't finish. Please try asking it more simply.", trace, self.max_steps)
