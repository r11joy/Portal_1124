"""The DEMO BRAIN: a pretend Claude that follows simple keyword rules. No AWS, no cost, no internet.

Why it exists: so the web page and the tests work before anyone has AWS keys. It is NOT smart. It only recognises
a handful of questions (skip, due, attendance, timetable, emails, notes, CGPA, morning briefing). The real Claude
(BedrockLLM) understands anything. Both plug into the agent the same way, so swapping is one setting.
"""
from __future__ import annotations

import json
import re
from datetime import datetime, timezone

from portal_core.dates import TZ

NAME = "Demo brain (no AWS)"

SUBJECT_WORDS = {"os": "Operating", "cn": "Networks", "ds": "Data Structures", "dbms": "Database", "se": "Software",
                 "dm": "Discrete", "maths": "Discrete", "math": "Discrete", "mathematics": "Discrete"}
FILLER = set("any anything do does did i my me the a an to in on of for is are what whats which when about from and or "
             "have has can show tell check please there new notices notice email emails mail mails".split())


def _use(i: int, name: str, **args) -> dict:
    return {"toolUse": {"toolUseId": f"demo{i}", "name": name, "input": args}}


def _subject(q: str):
    for word, full in SUBJECT_WORDS.items():
        if re.search(rf"\b{word}\b", q):
            return full
    return None


def _day(q: str) -> str:
    if "tomorrow" in q:
        return "tomorrow"
    for d in ("monday", "tuesday", "wednesday", "thursday", "friday", "saturday"):
        if d in q:
            return d
    return "today"


def _clock(iso: str) -> str:
    return datetime.fromisoformat(iso).astimezone(TZ).strftime("%I:%M %p").lstrip("0")


def _due(a: dict) -> str:
    d = datetime.fromisoformat(a["due"])
    when = "today" if a["days_left"] == 0 else "tomorrow" if a["days_left"] == 1 else d.strftime("%A")
    return f"{a['title']} for {a['course']}, due {when} at {d.strftime('%I:%M %p').lstrip('0')}"


def _plan(q: str) -> list[dict]:
    day = _day(q)
    if "briefing" in q or "good morning" in q:
        return [_use(1, "get_timetable", day="today"), _use(2, "get_attendance"),
                _use(3, "get_assignments", due_within_days=7), _use(4, "cgpa_target_plan", target_cgpa=7.5)]
    if "skip" in q or "bunk" in q:
        args = {"day": day}
        if _subject(q):
            args["subject"] = _subject(q)
        return [_use(1, "can_i_skip", **args)]
    if "cgpa" in q or "sgpa" in q or "internal" in q or "score" in q or "marks" in q:
        return [_use(1, "cgpa_target_plan", target_cgpa=7.5)]
    if any(w in q for w in ("clash", "pile", "crunch", "overlap", "too busy", "start first")):
        return [_use(1, "find_deadline_clashes")]
    if "due" in q or "assignment" in q or "homework" in q or "deadline" in q:
        return [_use(1, "get_assignments", due_within_days=7), _use(2, "search_emails", query="due deadline exam IA2 fee")]
    if "attendance" in q or "percent" in q:
        return [_use(1, "get_attendance", **({"subject": _subject(q)} if _subject(q) else {}))]
    if "timetable" in q or "classes" in q or "schedule" in q:
        return [_use(1, "get_timetable", day=day)]
    if "announce" in q:
        return [_use(1, "get_announcements")]
    if any(w in q for w in ("note", "module", "pdf", "topics", "material", "chapter", "syllabus")):
        words = " ".join(w for w in re.findall(r"[a-z0-9]+", q) if w not in FILLER)
        return [_use(1, "search_notes", query=words or q)]
    if "email" in q or "mail" in q or "notice" in q or "circular" in q or "prize" in q:
        words = " ".join(w for w in re.findall(r"[a-z0-9]+", q) if w not in FILLER) or "exam"
        return [_use(1, "search_emails", query=words)]
    return []


def _source_line(results: list[dict]) -> str:
    seen, times = [], []
    for r in results:
        if r.get("source") and r["source"] not in seen:
            seen.append(r["source"])
        if r.get("synced_at"):
            times.append(r["synced_at"])
    if not seen:
        return ""
    stale = any(r.get("stale") for r in results)
    return f" Source: {', '.join(seen)}, synced {_clock(max(times))}" + (" (older saved copy)" if stale else "") + "."


def _sentence(name: str, d: dict) -> str:
    if name == "can_i_skip":
        extra = [f"{s['name']} would drop from {s['percent_now']} to {s['percent_if_skipped']} percent"
                 for s in d["by_subject"] if s["verdict"] == "no"]
        return d["summary"] + (" " + "; ".join(extra) + "." if extra else "")
    if name == "get_attendance":
        low = [f"{s['name']} {s['percent']}%" for s in d["subjects"] if s["percent"] < d["threshold"]]
        if len(d["subjects"]) == 1:
            s = d["subjects"][0]
            return f"{s['name']} is at {s['percent']} percent ({s['attended']} of {s['held']} classes)."
        return ("Below 75 percent: " + ", ".join(low) + ".") if low else "You're at or above 75 percent in every subject."
    if name == "get_timetable":
        names = [c["name"] for c in d["classes"]]
        return f"On {d['weekday']} you have {len(names)} classes: {', '.join(names)}." if names else f"No classes on {d['weekday']}."
    if name == "get_assignments":
        rows = [a for a in d["assignments"] if a["status"] != "turned_in"]
        return ("Due soon: " + "; ".join(_due(a) for a in rows[:4]) + ".") if rows else "Nothing due soon in Classroom."
    if name == "search_emails":
        e = d["emails"]
        return ("Emails: " + "; ".join(f"{x['subject']}" for x in e[:3]) + ".") if e else "No matching emails."
    if name == "find_deadline_clashes":
        c = d["clashes"]
        if not c:
            return f"No clashes: nothing else lands within {d['window_hours']} hours of another deadline."
        g = c[0]
        names = " and ".join(f"{i['title'].split(':')[0]} ({i['course']})" for i in g["items"])
        return (f"Crunch warning: {g['count']} deadlines within {g['span_hours']:.0f} hours: {names}. "
                f"Start the one due first, {g['items'][0]['course']}, today.")
    if name == "get_announcements":
        return "Teacher posts: " + "; ".join(f"{a['course']}: {a['text']}" for a in d["announcements"][:3])
    if name == "cgpa_target_plan":
        if "subjects" not in d:
            return d.get("note", "Couldn't make a plan.")
        needs = [f"{s['name']}: {s['extra_internal_marks_needed']:.0f} out of {s['out_of_remaining_internals']:.0f} in the next internal"
                 for s in d["subjects"]]
        head = (f"To reach an SGPA of {d['target_sgpa']}, " if d["achievable"] else
                f"An SGPA of {d['target_sgpa']} isn't reachable with an end-sem of {d['assumed_see_percent']:.0f} percent; the best you can do is {d['sgpa_with_this_plan']}. Aim for: ")
        return head + "; ".join(needs[:3]) + ("." if len(needs) <= 3 else f"; and {len(needs) - 3} more subjects.")
    if name == "search_notes":
        m = d["matches"]
        return (f"Found in {m[0]['subject']} {m[0]['module']}, page {m[0]['page']}: {m[0]['snippet']}") if m else "I couldn't find that in your saved notes."
    if name == "list_notes":
        return "Saved notes: " + ", ".join(f"{n['subject']} {n['module']}" for n in d["notes"]) if d["notes"] else "You haven't saved any notes yet."
    if name == "get_note":
        n = d["notes"][0]
        return f"{n['subject']} {n['module']}: {n['text'][:300]}"
    if name == "save_note":
        s = d["saved"]
        return f"Saved your {s['subject']} {s['module']} notes ({s['pages']} pages)."
    return json.dumps(d)[:200]


def _compose(messages: list[dict]) -> str:
    names = {b["toolUse"]["toolUseId"]: b["toolUse"]["name"] for m in messages if m["role"] == "assistant" for b in m["content"] if "toolUse" in b}
    results = [b["toolResult"] for b in messages[-1]["content"] if "toolResult" in b]
    parts, metas = [], []
    for r in results:
        raw = re.sub(r"</?untrusted_data>", "", r["content"][0]["text"]).strip()
        if r["status"] != "success":
            parts.append(f"{names.get(r['toolUseId'], 'A tool')} had a problem: {raw[:120]}")
            continue
        d = json.loads(raw)
        metas.append(d)
        parts.append(_sentence(names[r["toolUseId"]], d))
    user_q = next((m["content"][0].get("text", "") for m in reversed(messages) if m["role"] == "user" and "text" in m["content"][0]), "").lower()
    if "briefing" in user_q:
        parts.insert(0, "Good morning.")
    return " ".join(parts) + _source_line(metas)


class DemoLLM:
    """Plugs into PortalAgent exactly like BedrockLLM."""
    name = NAME

    async def generate(self, system, messages, tools):
        last = messages[-1]["content"]
        if any("toolResult" in b for b in last):
            return {"stop_reason": "end_turn", "message": {"role": "assistant", "content": [{"text": _compose(messages)}]}}
        question = last[0]["text"].lower()
        calls = [c for c in _plan(question) if c["toolUse"]["name"] in {t["name"] for t in tools}]
        if not calls:
            help_text = ("I'm the demo brain, so I only understand a few things: can I skip, what's due, attendance, timetable, "
                         "emails, notes, SGPA targets, deadline clashes, and the morning briefing. The real Claude understands anything.")
            return {"stop_reason": "end_turn", "message": {"role": "assistant", "content": [{"text": help_text}]}}
        return {"stop_reason": "tool_use", "message": {"role": "assistant", "content": calls}}
