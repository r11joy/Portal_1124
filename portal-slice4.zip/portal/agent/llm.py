"""The "brain" behind a tiny interface, so we can swap it: real Claude on Amazon Bedrock, or a scripted fake for tests.

Messages use the Amazon Bedrock Converse shape everywhere:
  {"role": "user"|"assistant", "content": [{"text": ...} | {"toolUse": {...}} | {"toolResult": {...}}]}
"""
from __future__ import annotations

import asyncio
import os
from typing import Awaitable, Callable, Optional, Protocol


class LLM(Protocol):
    async def generate(self, system: str, messages: list[dict], tools: list[dict]) -> dict:
        """-> {"stop_reason": "end_turn" | "tool_use" | ..., "message": {"role": "assistant", "content": [...]}}"""


def to_bedrock_tools(tools: list[dict]) -> dict:
    """Our tool list [{name, description, input_schema}] -> Bedrock's toolConfig."""
    return {"tools": [{"toolSpec": {"name": t["name"], "description": t["description"] or t["name"],
                                    "inputSchema": {"json": t["input_schema"]}}} for t in tools]}


class BedrockLLM:
    """Claude on Amazon Bedrock via the Converse API.

    Needs: AWS credentials (aws configure), AWS_REGION, and BEDROCK_MODEL_ID (copy from the Bedrock console;
    some models need an 'inference profile' ID instead).
    """

    def __init__(self, model_id: Optional[str] = None, region: Optional[str] = None, client=None, max_tokens: int = 1024):
        self.model_id = model_id or os.environ.get("BEDROCK_MODEL_ID")
        if not self.model_id:
            raise RuntimeError("Set BEDROCK_MODEL_ID to the model ID from the Bedrock console.")
        if client is None:
            import boto3  # imported here so tests and the rest of Portal work without it
            client = boto3.client("bedrock-runtime", region_name=region or os.environ.get("AWS_REGION", "us-east-1"))
        self.client, self.max_tokens = client, max_tokens

    async def generate(self, system, messages, tools):
        kwargs = dict(modelId=self.model_id, system=[{"text": system}], messages=messages,
                      inferenceConfig={"maxTokens": self.max_tokens, "temperature": 0.2})
        if tools:
            kwargs["toolConfig"] = to_bedrock_tools(tools)
        resp = await asyncio.to_thread(lambda: self.client.converse(**kwargs))  # boto3 is blocking
        return {"stop_reason": resp["stopReason"], "message": resp["output"]["message"]}


class ScriptedLLM:
    """A fake brain for tests: you give it a function that decides what to say next. No network, no cost."""

    def __init__(self, policy: Callable[[str, list[dict], list[dict]], dict | Awaitable[dict]]):
        self.policy, self.calls = policy, []

    async def generate(self, system, messages, tools):
        self.calls.append({"system": system, "messages": [dict(m) for m in messages], "tools": tools})
        out = self.policy(system, messages, tools)
        return await out if asyncio.iscoroutine(out) else out
