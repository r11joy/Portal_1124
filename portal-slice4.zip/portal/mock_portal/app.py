"""A pretend college ERP portal (login form + HTML tables), like the real thing:
no API, just pages. The Playwright adapter scrapes this exactly as it would a real portal.

Run:  python -m mock_portal.app   (serves on http://127.0.0.1:5055)
"""
import os
from functools import wraps

from flask import Flask, redirect, render_template_string, request, session, url_for

from . import data

app = Flask(__name__)
app.secret_key = "mock-portal-not-a-real-secret"

BASE = """
<!doctype html><html><head><meta charset="utf-8"><title>College ERP - {{ title }}</title>
<style>body{font-family:Arial;margin:2rem}table{border-collapse:collapse}td,th{border:1px solid #888;padding:6px 12px}
nav a{margin-right:1rem}</style></head><body>
{% if session.get('user') %}<nav><a href="/dashboard">Home</a><a href="/attendance">Attendance</a>
<a href="/marks">Internal Marks</a><a href="/timetable">Timetable</a><a href="/logout">Logout</a></nav>{% endif %}
<h2>{{ title }}</h2>{{ body|safe }}</body></html>
"""


def page(title, body):
    return render_template_string(BASE, title=title, body=body)


def login_required(fn):
    @wraps(fn)
    def wrapper(*a, **kw):
        if not session.get("user"):
            return redirect(url_for("login"))
        return fn(*a, **kw)
    return wrapper


@app.route("/", methods=["GET"])
def index():
    return redirect(url_for("dashboard") if session.get("user") else url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    error = ""
    if request.method == "POST":
        if request.form.get("usn") == data.USERNAME and request.form.get("password") == data.PASSWORD:
            session["user"] = data.USERNAME
            return redirect(url_for("dashboard"))
        error = '<p id="login-error" style="color:red">Invalid USN or password</p>'
    body = f"""{error}<form method="post">
      <p><label>USN <input name="usn" id="usn"></label></p>
      <p><label>Password <input name="password" id="password" type="password"></label></p>
      <p><button type="submit" id="login-btn">Login</button></p></form>"""
    return page("Student Login", body)


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/dashboard")
@login_required
def dashboard():
    return page("Dashboard", f"<p>Welcome, {data.STUDENT_NAME} ({data.USERNAME})</p>")


@app.route("/attendance")
@login_required
def attendance():
    rows = ""
    for code, name, short, credits in data.SUBJECTS:
        att, held = data.ATTENDANCE[code]
        pct = f"{att / held * 100:.1f}%"
        rows += (f'<tr data-code="{code}"><td>{code}</td><td>{name}</td>'
                 f"<td>{att}</td><td>{held}</td><td>{pct}</td></tr>")
    body = ('<table id="attendance-table"><thead><tr><th>Code</th><th>Subject</th><th>Attended</th>'
            f"<th>Held</th><th>%</th></tr></thead><tbody>{rows}</tbody></table>")
    return page("Attendance", body)


@app.route("/marks")
@login_required
def marks():
    rows = ""
    for code, name, short, credits in data.SUBJECTS:
        ia1, ia2 = data.MARKS[code]
        cell = lambda v: "-" if v is None else str(v)
        rows += (f'<tr data-code="{code}"><td>{code}</td><td>{name}</td><td>{credits}</td>'
                 f"<td>{cell(ia1)}</td><td>{cell(ia2)}</td></tr>")
    body = ('<table id="marks-table"><thead><tr><th>Code</th><th>Subject</th><th>Credits</th>'
            f"<th>IA1 /25</th><th>IA2 /25</th></tr></thead><tbody>{rows}</tbody></table>")
    return page("Internal Marks", body)


@app.route("/timetable")
@login_required
def timetable():
    rows = ""
    for day, codes in data.TIMETABLE.items():
        cells = "".join(f"<td>{c}</td>" for c in codes)
        rows += f'<tr data-day="{day}"><th>{day}</th>{cells}</tr>'
    body = f'<table id="timetable"><tbody>{rows}</tbody></table>'
    return page("Timetable", body)


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", "5055")), debug=False)
