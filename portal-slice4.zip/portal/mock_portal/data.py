"""Fake student data for the mock college portal. Edit freely to tune demos."""

USERNAME = "1XX23CS001"
PASSWORD = "demo123"
STUDENT_NAME = "Demo Student"

# code, name, short name, credits
SUBJECTS = [
    ("CS501", "Operating Systems", "OS", 4),
    ("CS502", "Computer Networks", "CN", 4),
    ("CS503", "Data Structures", "DS", 3),
    ("CS504", "Database Management Systems", "DBMS", 4),
    ("CS505", "Software Engineering", "SE", 3),
    ("MA506", "Discrete Mathematics", "DM", 3),
]

# code -> (classes attended, classes held)
ATTENDANCE = {
    "CS501": (37, 50),   # 74.0%  -> below 75, the demo's "don't skip OS"
    "CS502": (38, 46),   # 82.6%
    "CS503": (34, 44),   # 77.3%
    "CS504": (28, 38),   # 73.7%
    "CS505": (36, 40),   # 90.0%
    "MA506": (30, 42),   # 71.4%
}

# code -> [IA1, IA2] out of 25 each. None = test not conducted yet.
MARKS = {
    "CS501": [18, None],
    "CS502": [21, None],
    "CS503": [16, None],
    "CS504": [19, None],
    "CS505": [22, None],
    "MA506": [14, None],
}

# weekday -> list of subject codes, in period order
TIMETABLE = {
    "Mon": ["CS501", "CS502", "CS503", "CS504", "CS505"],
    "Tue": ["MA506", "CS501", "CS504", "CS502"],
    "Wed": ["CS503", "MA506", "CS505", "CS501", "CS502"],
    "Thu": ["CS504", "CS503", "MA506", "CS501"],
    "Fri": ["CS502", "CS505", "CS504", "CS503", "MA506"],
    "Sat": ["CS501", "CS503"],
}
