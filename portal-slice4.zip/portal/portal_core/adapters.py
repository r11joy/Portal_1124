"""Portal adapters: the ONLY code that knows what a specific college's website looks like.

To support a new college, write one new adapter class (same 4 async methods) and set PORTAL_ADAPTER.
Nothing else in Portal changes. That is the whole "swap one MCP server" claim, in code.
"""
from __future__ import annotations

import asyncio
import os
from abc import ABC, abstractmethod


class PortalAdapter(ABC):
    name = "base"

    @abstractmethod
    async def fetch_attendance(self) -> list[dict]:
        """-> [{code, name, attended, held, portal_percent}]"""

    @abstractmethod
    async def fetch_marks(self) -> list[dict]:
        """-> [{code, name, credits, ia: [float|None, ...]}]"""

    @abstractmethod
    async def fetch_timetable(self) -> dict[str, list[str]]:
        """-> {"Mon": [subject codes in period order], ...}"""

    async def close(self) -> None:
        pass


class MockERPAdapter(PortalAdapter):
    """Scrapes the pretend portal in mock_portal/ with a real browser (Playwright)."""

    name = "mock-erp"

    def __init__(self, base_url: str, username: str, password: str):
        self.base_url = base_url.rstrip("/")
        self.username, self.password = username, password
        self._pw = self._browser = self._page = None
        self._lock = asyncio.Lock()

    async def _ensure_page(self):
        if self._page is None:
            from playwright.async_api import async_playwright
            self._pw = await async_playwright().start()
            self._browser = await self._pw.chromium.launch()
            self._page = await self._browser.new_page()
        return self._page

    async def _goto_logged_in(self, path: str):
        """Open a page; if the portal bounced us to the login form, log in once and retry."""
        page = await self._ensure_page()
        await page.goto(f"{self.base_url}{path}")
        if "/login" in page.url:
            await page.fill("#usn", self.username)
            await page.fill("#password", self.password)
            await page.click("#login-btn")
            if await page.query_selector("#login-error"):
                raise PermissionError("Portal rejected the saved credentials")
            await page.goto(f"{self.base_url}{path}")
        return page

    async def fetch_attendance(self):
        async with self._lock:
            page = await self._goto_logged_in("/attendance")
            rows = await page.eval_on_selector_all(
                "#attendance-table tbody tr",
                "els => els.map(e => [...e.querySelectorAll('td')].map(td => td.innerText.trim()))",
            )
        return [
            {"code": r[0], "name": r[1], "attended": int(r[2]), "held": int(r[3]), "portal_percent": r[4]}
            for r in rows
        ]

    async def fetch_marks(self):
        async with self._lock:
            page = await self._goto_logged_in("/marks")
            rows = await page.eval_on_selector_all(
                "#marks-table tbody tr",
                "els => els.map(e => [...e.querySelectorAll('td')].map(td => td.innerText.trim()))",
            )
        num = lambda v: None if v in ("-", "") else float(v)
        return [
            {"code": r[0], "name": r[1], "credits": int(r[2]), "ia": [num(v) for v in r[3:]]}
            for r in rows
        ]

    async def fetch_timetable(self):
        async with self._lock:
            page = await self._goto_logged_in("/timetable")
            rows = await page.eval_on_selector_all(
                "#timetable tbody tr",
                "els => els.map(e => [e.querySelector('th').innerText.trim(), "
                "...[...e.querySelectorAll('td')].map(td => td.innerText.trim())])",
            )
        return {r[0]: r[1:] for r in rows}

    async def close(self):
        if self._browser:
            await self._browser.close()
        if self._pw:
            await self._pw.stop()
        self._pw = self._browser = self._page = None


def build_adapter() -> PortalAdapter:
    """Pick the adapter from environment variables (never hard-code credentials)."""
    kind = os.environ.get("PORTAL_ADAPTER", "mock-erp")
    if kind == "mock-erp":
        return MockERPAdapter(
            base_url=os.environ.get("PORTAL_URL", "http://127.0.0.1:5055"),
            username=os.environ.get("PORTAL_USER", "1XX23CS001"),
            password=os.environ.get("PORTAL_PASS", "demo123"),
        )
    raise ValueError(f"Unknown PORTAL_ADAPTER {kind!r}. Write an adapter class and register it here.")
