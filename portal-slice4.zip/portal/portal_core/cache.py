"""Tiny JSON cache so a flaky portal never breaks an answer: serve the last good copy, flagged as stale."""
from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path

CACHE_DIR = Path(os.environ.get("PORTAL_CACHE_DIR", Path(__file__).resolve().parent.parent / ".cache"))


def save(key: str, data) -> str:
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).isoformat(timespec="seconds")
    (CACHE_DIR / f"{key}.json").write_text(json.dumps({"synced_at": stamp, "data": data}))
    return stamp


def load(key: str):
    path = CACHE_DIR / f"{key}.json"
    if not path.exists():
        return None
    blob = json.loads(path.read_text())
    return blob["synced_at"], blob["data"]
