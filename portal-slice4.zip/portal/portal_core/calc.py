"""Deterministic academic math. The LLM never does these calculations; it calls tools that use this file.

Grade scheme and marks structure are assumptions (VTU-style) held in ONE place at the top, so they are
easy to change to match your college's real rules:
  - Each subject: CIE (internals) out of 50 = IA1 + IA2 (25 each), SEE (end sem) out of 100 scaled to 50.
  - Total out of 100 -> grade points via GRADE_BANDS.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from fractions import Fraction
from typing import Optional

# ----------------------------------------------------------------------------- assumptions to confirm
ATTENDANCE_THRESHOLD = 75.0
IA_MAX_EACH = 25
SEE_WEIGHT_MAX = 50  # SEE paper (out of 100) is scaled down to this many marks
# (minimum total out of 100, grade points, letter)
GRADE_BANDS = [(90, 10, "O"), (80, 9, "A+"), (70, 8, "A"), (60, 7, "B+"), (55, 6, "B"), (50, 5, "C"), (40, 4, "P"), (0, 0, "F")]


# ----------------------------------------------------------------------------- attendance
def _frac(x) -> Fraction:
    return Fraction(str(x))


def percent(attended: int, held: int) -> float:
    return round(attended / held * 100, 1) if held else 0.0


def skippable(attended: int, held: int, threshold: float = ATTENDANCE_THRESHOLD) -> int:
    """How many MORE classes can be missed and still stay at or above the threshold. 0 if already below."""
    t = _frac(threshold)
    k = math.floor((100 * attended - t * held) / t)
    return max(0, k)


def classes_needed(attended: int, held: int, threshold: float = ATTENDANCE_THRESHOLD) -> int:
    """How many CONSECUTIVE classes must be attended to climb back to the threshold. 0 if already there."""
    t = _frac(threshold)
    if 100 * attended >= t * held:
        return 0
    return math.ceil((t * held - 100 * attended) / (100 - t))


def skip_verdict(attended: int, held: int, n_missed: int, threshold: float = ATTENDANCE_THRESHOLD, caution_buffer: int = 2) -> dict:
    """Should you miss n_missed classes of this subject?  verdict: 'no' | 'risky' | 'ok'."""
    now = percent(attended, held)
    after = percent(attended, held + n_missed)
    buffer_after = skippable(attended, held + n_missed, threshold)
    if _frac(100 * attended) < _frac(threshold) * (held + n_missed):
        verdict = "no"
    elif buffer_after < caution_buffer:
        verdict = "risky"
    else:
        verdict = "ok"
    return {
        "verdict": verdict,
        "percent_now": now,
        "percent_if_skipped": after,
        "threshold": threshold,
        "spare_classes_after_skipping": buffer_after,
        "classes_to_attend_to_recover": classes_needed(attended, held + n_missed, threshold) if verdict == "no" else 0,
    }


# ----------------------------------------------------------------------------- grades and CGPA
def grade_for(total: float) -> tuple[int, str]:
    for minimum, gp, letter in GRADE_BANDS:
        if total >= minimum:
            return gp, letter
    return 0, "F"


@dataclass
class Subject:
    code: str
    name: str
    credits: int
    ia_scores: list[Optional[float]] = field(default_factory=list)  # None = not conducted yet

    @property
    def ia_earned(self) -> float:
        return sum(s for s in self.ia_scores if s is not None)

    @property
    def ia_remaining_max(self) -> float:
        return sum(IA_MAX_EACH for s in self.ia_scores if s is None)


def sgpa(grade_points_by_credits: list[tuple[int, int]]) -> float:
    total_credits = sum(c for c, _ in grade_points_by_credits)
    return round(sum(c * gp for c, gp in grade_points_by_credits) / total_credits, 2) if total_credits else 0.0


def required_sgpa_for_cgpa(target_cgpa: float, prev_cgpa: float, prev_credits: int, this_credits: int) -> float:
    return (target_cgpa * (prev_credits + this_credits) - prev_cgpa * prev_credits) / this_credits


def plan_for_sgpa(subjects: list[Subject], target_sgpa: float, assumed_see_percent: float = 60.0) -> dict:
    """Cheapest way (fewest extra internal marks) to reach target_sgpa, given an assumed end-sem percentage.

    Greedy: start each subject at the best grade it already gets with zero extra marks, then repeatedly buy
    the grade upgrade with the lowest marginal cost per grade-point-credit until the target is met.
    """
    see_scaled = assumed_see_percent / 100 * SEE_WEIGHT_MAX

    def extra_needed(s: Subject, minimum_total: int) -> float:
        return max(0.0, math.ceil(minimum_total - s.ia_earned - see_scaled - 1e-9))

    # grade options per subject, ascending by grade points: (gp, letter, extra marks needed in remaining IA, feasible)
    options: dict[str, list[tuple[int, str, float, bool]]] = {}
    for s in subjects:
        opts = []
        for minimum, gp, letter in sorted(GRADE_BANDS, key=lambda b: b[1]):
            need = extra_needed(s, minimum)
            opts.append((gp, letter, need, need <= s.ia_remaining_max))
        options[s.code] = opts

    chosen: dict[str, int] = {}  # code -> index into options
    for s in subjects:
        idx = 0
        for i, (_, _, need, feasible) in enumerate(options[s.code]):
            if need == 0 and feasible:
                idx = i
        chosen[s.code] = idx

    def current_sgpa() -> float:
        return sgpa([(s.credits, options[s.code][chosen[s.code]][0]) for s in subjects])

    while current_sgpa() < target_sgpa:
        best = None
        for s in subjects:
            i = chosen[s.code]
            for j in range(i + 1, len(options[s.code])):
                gp, _, need, feasible = options[s.code][j]
                if not feasible:
                    continue
                cur_gp, _, cur_need, _ = options[s.code][i]
                gain = (gp - cur_gp) * s.credits
                cost = max(need - cur_need, 0.25)
                ratio = cost / gain
                if best is None or ratio < best[0]:
                    best = (ratio, s.code, j)
        if best is None:
            break
        chosen[best[1]] = best[2]

    achieved = current_sgpa()
    rows = []
    for s in subjects:
        gp, letter, need, feasible = options[s.code][chosen[s.code]]
        rows.append({
            "code": s.code, "name": s.name, "credits": s.credits,
            "target_grade": letter, "grade_points": gp,
            "internal_marks_so_far": s.ia_earned,
            "extra_internal_marks_needed": need,
            "out_of_remaining_internals": s.ia_remaining_max,
        })
    return {
        "target_sgpa": target_sgpa,
        "achievable": achieved >= target_sgpa,
        "sgpa_with_this_plan": achieved,
        "assumed_see_percent": assumed_see_percent,
        "subjects": rows,
    }
