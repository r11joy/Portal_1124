"""Deadline-clash finder. Pure code, no AI: groups pending items whose due times fall close together.

WHY: "Anything due?" lists deadlines. A clash warning says "these two land within 48 hours, start the bigger one first".
"""
from __future__ import annotations

from datetime import datetime


def find_clashes(items: list[dict], window_hours: float = 48, min_items: int = 2) -> list[dict]:
    """items: [{course, title, due (ISO), status}]. Turned-in items are ignored.
    A cluster starts at the earliest pending item and takes every item due within window_hours of that start."""
    pending = sorted((i for i in items if i.get("status") != "turned_in"), key=lambda i: i["due"])
    clusters, cur = [], []
    for it in pending:
        if cur and (datetime.fromisoformat(it["due"]) - datetime.fromisoformat(cur[0]["due"])).total_seconds() > window_hours * 3600:
            clusters.append(cur)
            cur = []
        cur.append(it)
    if cur:
        clusters.append(cur)
    out = []
    for c in clusters:
        if len(c) >= min_items:
            span = (datetime.fromisoformat(c[-1]["due"]) - datetime.fromisoformat(c[0]["due"])).total_seconds() / 3600
            out.append({"count": len(c), "first_due": c[0]["due"], "last_due": c[-1]["due"], "span_hours": round(span, 1),
                        "items": [{"course": i["course"], "title": i["title"], "due": i["due"]} for i in c]})
    return out
