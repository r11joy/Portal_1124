"""Date helpers so fake data always looks fresh ("due Thursday" = the coming Thursday)."""
from __future__ import annotations

from datetime import date, datetime, time, timedelta
from zoneinfo import ZoneInfo

TZ = ZoneInfo("Asia/Kolkata")
WEEKDAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]


def today() -> date:
    return datetime.now(TZ).date()


def next_weekday(name: str, at: str = "23:59", *, ref: date | None = None, now: datetime | None = None) -> datetime:
    """The coming occurrence of a weekday at HH:MM local time. Today counts only if that time hasn't passed yet.

    Pass `ref` (a date) to pin the calendar day in tests; `now` is the clock to compare against (defaults to the
    real time when `ref` isn't given, and is ignored when only `ref` is given, so old tests stay predictable)."""
    if now is None and ref is None:
        now = datetime.now(TZ)
    ref = ref or now.date()
    ahead = (WEEKDAYS.index(name[:3].title()) - ref.weekday()) % 7
    hh, mm = (int(x) for x in at.split(":"))
    candidate = datetime.combine(ref + timedelta(days=ahead), time(hh, mm), TZ)
    if now is not None and candidate < now:
        candidate += timedelta(days=7)
    return candidate


def days_ago(n: int, at: str = "10:00", *, ref: date | None = None) -> datetime:
    ref = ref or today()
    hh, mm = (int(x) for x in at.split(":"))
    return datetime.combine(ref - timedelta(days=n), time(hh, mm), TZ)
