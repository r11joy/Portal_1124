"""The note store: save PDFs/text under a subject + module, then find them again.

Plain Python, no AI. Storage is a folder on disk for now (swap for S3 later by changing _write_file).
Search is simple word counting (TF-IDF style); ChromaDB/embeddings can replace `search` later without
touching the MCP server or the agent.
"""
from __future__ import annotations

import json
import math
import re
import shutil
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

STOPWORDS = set("a an the and or of to in on for is are was were be it this that with what which who how do does my me i you your from at as by about give show tell".split())


def _tokens(text: str) -> list[str]:
    return [t for t in re.findall(r"[a-z0-9]+", text.lower()) if t not in STOPWORDS and (len(t) > 1 or t.isdigit())]


def _slug(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-") or "x"


def _digits(s: str) -> str:
    return "".join(re.findall(r"\d+", s))


def _word_match(a: str, b: str) -> bool:
    """'maths' matches 'mathematics'; 'os' matches 'os'. Words match on equality or a shared 4+ letter start."""
    if a == b:
        return True
    n = 0
    for x, y in zip(a, b):
        if x != y:
            break
        n += 1
    return n >= 4


def subject_matches(query: str, stored: str) -> bool:
    q = [t for t in re.findall(r"[a-z0-9]+", query.lower())]
    s = [t for t in re.findall(r"[a-z0-9]+", stored.lower())]
    return bool(q) and all(any(_word_match(qt, st) for st in s) for qt in q)


def extract_pages(path: Path) -> list[str]:
    """One string per page. PDFs via pdfplumber; .txt/.md as a single page."""
    if path.suffix.lower() == ".pdf":
        import pdfplumber
        with pdfplumber.open(path) as pdf:
            return [(p.extract_text() or "").strip() for p in pdf.pages]
    return [path.read_text(errors="ignore").strip()]


class NoteStore:
    def __init__(self, root: Path):
        self.root = Path(root)
        self.files = self.root / "files"
        self.index_path = self.root / "index.json"
        self.files.mkdir(parents=True, exist_ok=True)
        self._notes: list[dict] = json.loads(self.index_path.read_text()) if self.index_path.exists() else []

    def _save_index(self) -> None:
        self.index_path.write_text(json.dumps(self._notes, indent=1))

    def _write_file(self, src: Path, note_id: str) -> str:
        dest = self.files / f"{note_id}{src.suffix.lower()}"
        shutil.copy2(src, dest)
        return str(dest)

    # ------------------------------------------------------------------ write
    def save(self, subject: str, module: str, file_path: Optional[str] = None, text: Optional[str] = None, title: Optional[str] = None) -> dict:
        if not subject.strip() or not module.strip():
            raise ValueError("Both subject and module are required, e.g. subject='Maths', module='Module 1'")
        if file_path:
            src = Path(file_path).expanduser()
            if not src.is_file():
                raise FileNotFoundError(f"No such file: {file_path}")
            pages = extract_pages(src)
            title = title or src.stem
        elif text:
            src, pages, title = None, [text.strip()], title or f"{subject} {module} (typed note)"
        else:
            raise ValueError("Give either file_path or text")
        if not any(pages):
            raise ValueError("No readable text found (a scanned/photo PDF needs OCR, which isn't built yet)")
        note_id = f"{_slug(subject)}-{_slug(module)}-{len(self._notes) + 1}"
        stored = self._write_file(src, note_id) if src else None
        note = {"id": note_id, "subject": subject.strip(), "module": module.strip(), "title": title, "file": stored,
                "pages": pages, "saved_at": datetime.now(timezone.utc).isoformat(timespec="seconds")}
        self._notes.append(note)
        self._save_index()
        return self._summary(note)

    # ------------------------------------------------------------------ read
    @staticmethod
    def _summary(n: dict) -> dict:
        return {"id": n["id"], "subject": n["subject"], "module": n["module"], "title": n["title"],
                "pages": len(n["pages"]), "file": n["file"], "saved_at": n["saved_at"]}

    def list(self, subject: Optional[str] = None) -> list[dict]:
        return [self._summary(n) for n in self._notes if not subject or subject_matches(subject, n["subject"])]

    def _find(self, subject: str, module: Optional[str]) -> list[dict]:
        hits = [n for n in self._notes if subject_matches(subject, n["subject"])]
        if module:
            d = _digits(module)
            hits = [n for n in hits if (d and _digits(n["module"]) == d) or (not d and subject_matches(module, n["module"]))]
        return hits

    def get(self, subject: str, module: Optional[str] = None, max_chars: int = 6000) -> dict:
        hits = self._find(subject, module)
        if not hits:
            raise LookupError(f"No saved notes for subject={subject!r} module={module!r}. Saved: {[(n['subject'], n['module']) for n in self._notes]}")
        out = []
        budget = max_chars
        for n in hits:
            text = "\n\n".join(f"[page {i + 1}] {p}" for i, p in enumerate(n["pages"]))
            out.append({**self._summary(n), "text": text[:budget], "truncated": len(text) > budget})
            budget = max(0, budget - len(text))
            if budget == 0:
                break
        return {"notes": out}

    def search(self, query: str, subject: Optional[str] = None, limit: int = 5) -> list[dict]:
        q = _tokens(query)
        if not q:
            return []
        pool = [(n, i, p) for n in self._notes if not subject or subject_matches(subject, n["subject"]) for i, p in enumerate(n["pages"])]
        if not pool:
            return []
        docs = [Counter(_tokens(p + " " + n["subject"] + " " + n["module"] + " " + n["title"])) for n, _, p in pool]
        N = len(docs)
        df = Counter(t for d in docs for t in d)
        scored = []
        for (n, i, p), d in zip(pool, docs):
            score = sum((1 + math.log(d[t])) * math.log(1 + N / (1 + df[t])) for t in q if d[t])
            if score > 0:
                scored.append((score, n, i, p))
        scored.sort(key=lambda x: -x[0])
        results = []
        for score, n, i, p in scored[:limit]:
            low = p.lower()
            pos = min((low.find(t) for t in q if low.find(t) >= 0), default=0)
            start = max(0, pos - 120)
            results.append({"id": n["id"], "subject": n["subject"], "module": n["module"], "title": n["title"], "page": i + 1,
                            "score": round(score, 2), "snippet": p[start:start + 320].replace("\n", " ")})
        return results
