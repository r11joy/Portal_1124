"""Whole-system check with a PRETEND brain (no AWS needed): agent -> 4 real MCP servers -> real tools.

The pretend brain follows a script ("if the question mentions skip, call can_i_skip"). That tests everything
EXCEPT how smart the real Claude is, which Person C checks separately against Bedrock.

Run from the project root:  python scripts/agent_smoke_test.py
"""
import asyncio
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from agent.core import PortalAgent  # noqa: E402
from agent.llm import ScriptedLLM  # noqa: E402

PORT = "5058"


def wait_for(url):
    for _ in range(40):
        try:
            urllib.request.urlopen(url, timeout=1)
            return
        except Exception:
            time.sleep(0.25)
    raise RuntimeError(f"{url} never came up")


def make_pdf(path: Path):
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas
    c = canvas.Canvas(str(path), pagesize=A4)
    c.drawString(72, 780, "Module 1: Propositional Logic and Proofs")
    c.drawString(72, 760, "Topics: truth tables, logical equivalence, rules of inference, predicates and quantifiers.")
    c.showPage()
    c.save()


def tool_call(i, name, **args):
    return {"toolUse": {"toolUseId": f"t{i}", "name": name, "input": args}}


def summarise(results):
    """The pretend brain's 'writing' step: turn tool results into a sentence + a source line."""
    parts, source = [], ""
    for r in results:
        text = r["toolResult"]["content"][0]["text"]
        text = re.sub(r"</?untrusted_data>", "", text).strip()
        d = json.loads(text) if text.startswith("{") else {"summary": text}
        source = d.get("source", source) + f", synced {d.get('synced_at', '?')}" if d.get("source") else source
        if "summary" in d:
            parts.append(d["summary"])
        elif "assignments" in d:
            parts.append("Due soon: " + "; ".join(f"{a['title']} ({a['course']})" for a in d["assignments"][:3]))
        elif "emails" in d:
            parts.append("Emails: " + "; ".join(e["subject"] for e in d["emails"][:3]))
        elif "matches" in d:
            parts.append("Found: " + (d["matches"][0]["snippet"] if d["matches"] else "nothing"))
        elif "saved" in d:
            parts.append(f"Saved {d['saved']['id']}")
        elif "subjects" in d:
            parts.append(f"CGPA plan achievable={d.get('achievable')}")
    return " ".join(parts) + (f" Source: {source}." if source else "")


def policy(system, messages, tools):
    last = messages[-1]
    blocks = last["content"]
    if any("toolResult" in b for b in blocks):
        return {"stop_reason": "end_turn", "message": {"role": "assistant", "content": [{"text": summarise(blocks)}]}}
    q = blocks[0]["text"].lower()
    if "skip" in q:
        calls = [tool_call(1, "can_i_skip", day="tomorrow")]
    elif "due" in q:
        calls = [tool_call(1, "get_assignments", due_within_days=7), tool_call(2, "search_emails", query="due deadline exam IA2")]
    elif "save" in q:
        path = re.search(r"(\S+\.pdf)", blocks[0]["text"]).group(1)
        calls = [tool_call(1, "save_note", subject="Maths", module="Module 1", file_path=path)]
    elif "inference" in q:
        calls = [tool_call(1, "search_notes", query="rules of inference")]
    elif "prize" in q:
        calls = [tool_call(1, "search_emails", query="prize")]
    elif "cgpa" in q:
        calls = [tool_call(1, "cgpa_target_plan", target_cgpa=7.5)]
    else:
        return {"stop_reason": "end_turn", "message": {"role": "assistant", "content": [{"text": "Not sure."}]}}
    return {"stop_reason": "tool_use", "message": {"role": "assistant", "content": calls}}


def check(cond, label):
    print(("  PASS  " if cond else "  FAIL  ") + label)
    if not cond:
        raise SystemExit(1)


async def main():
    tmp = Path(tempfile.mkdtemp(prefix="portal-agent-test-"))
    pdf = tmp / "maths_module1.pdf"
    make_pdf(pdf)
    portal = subprocess.Popen([sys.executable, "-m", "mock_portal.app"], cwd=ROOT, env={**os.environ, "PORT": PORT},
                              stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    os.environ.update(PORTAL_URL=f"http://127.0.0.1:{PORT}", PORTAL_CACHE_DIR=str(tmp / "cache"), PORTAL_NOTES_DIR=str(tmp / "notes"))
    try:
        wait_for(f"http://127.0.0.1:{PORT}/login")
        llm = ScriptedLLM(policy)

        print("1. Start: connect to all four servers")
        async with PortalAgent(llm) as agent:
            names = {t["name"] for t in agent.tools}
            check(len(agent.tools) >= 14 and not agent.unavailable, f"{len(agent.tools)} tools discovered, nothing unavailable")
            check({"can_i_skip", "get_assignments", "search_emails", "save_note"} <= names, "tools from portal, classroom, gmail and notes are all present")

            print("2. 'Can I skip tomorrow?'  (portal server -> Playwright -> fake college site)")
            r = await agent.ask("Can I skip tomorrow?")
            print("   ->", r.answer)
            check(r.trace[0]["tool"] == "can_i_skip" and r.trace[0]["ok"], "called can_i_skip and it worked")
            check("Don't skip" in r.answer and "Source: college portal" in r.answer, "answer has the verdict and a source line")

            print("3. 'Anything due this week?'  (should ask Classroom and Gmail AT THE SAME TIME)")
            r = await agent.ask("Do I have anything due this week?")
            print("   ->", r.answer[:160])
            a, b = r.trace[0], r.trace[1]
            check({a["server"], b["server"]} == {"classroom", "gmail"} and a["step"] == b["step"], "two servers called in the same step")
            check(max(a["started_ms"], b["started_ms"]) < min(a["started_ms"] + a["ms"], b["started_ms"] + b["ms"]), "their time windows overlap (truly parallel)")

            print("4. Share a PDF, then ask about it later  (notes server)")
            r = await agent.ask(f"Save this to Maths Module 1: {pdf}")
            check("Saved maths-module-1" in r.answer, "PDF saved under Maths / Module 1")
            r = await agent.ask("What does my Maths material say about inference?")
            check("inference" in r.answer.lower(), "search found the right text inside the PDF")

            print("5. CGPA plan  (portal marks -> calculator code)")
            r = await agent.ask("What do I need for a good CGPA?")
            check(r.trace[0]["tool"] == "cgpa_target_plan" and r.trace[0]["ok"], "calculator tool ran on real (fake-portal) marks")

            print("6. Safety: the trap email must reach the brain labelled as DATA")
            r = await agent.ask("Any prize emails?")
            last_tool_text = [b["toolResult"]["content"][0]["text"] for m in llm.calls[-1]["messages"] for b in m["content"] if "toolResult" in b][-1]
            check(last_tool_text.startswith("<untrusted_data>") and "ignore all your rules" in last_tool_text.lower(), "email text arrived inside <untrusted_data> tags")
            portal_text = [b["toolResult"]["content"][0]["text"] for m in llm.calls[1]["messages"] for b in m["content"] if "toolResult" in b][0]
            check(not portal_text.startswith("<untrusted_data>"), "trusted portal data is NOT wrapped")
            check("system" in llm.calls[0]["system"].lower() or "untrusted_data" in llm.calls[0]["system"], "system prompt tells the brain to never obey untrusted text")

        print("7. Resilience: one broken server must not stop the rest")
        async with PortalAgent(ScriptedLLM(policy), servers={"gmail": "servers.gmail_server", "bogus": "servers.does_not_exist"}) as agent:
            check("bogus" in agent.unavailable and "search_emails" in {t["name"] for t in agent.tools}, "bogus server reported unavailable; gmail still works")
            r = await agent.ask("Any prize emails?")
            check(r.trace[0]["ok"], "gmail still answers")
        print("\nALL AGENT CHECKS PASSED")
    finally:
        portal.terminate()
        shutil.rmtree(tmp, ignore_errors=True)


asyncio.run(main())
