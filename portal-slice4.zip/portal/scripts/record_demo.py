"""Records a paced screen video of the Portal web page, for the pitch video.

WHAT: starts the fake college site + the Portal web page, opens it in a headless browser at 1920x1080,
      types questions slowly with a visible cursor, waits so a viewer can read, saves demo.mp4 + timeline.txt.
WHY:  a pitch video needs smooth, readable footage. Doing it by script means we can re-record in one command
      after the real Claude (Bedrock) is plugged in.

Run from the project root:  python scripts/record_demo.py [output_folder]
"""
import os
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUT = Path(sys.argv[1] if len(sys.argv) > 1 else ROOT / "demo_footage")
PORTAL_PORT, WEB_PORT = "5069", "8011"
ZOOM = 1.5          # makes everything bigger so it is readable in a video

CURSOR_JS = """
(() => {
  const c = document.createElement('div');
  c.id = '__cur';
  c.style.cssText = 'position:fixed;z-index:99999;width:26px;height:26px;border-radius:50%;background:rgba(253,155,54,.85);border:3px solid #1B1F6B;pointer-events:none;left:-50px;top:-50px;transition:left .5s ease,top .5s ease;';
  document.body.appendChild(c);
  window.__moveCur = (x, y) => { c.style.left = x + 'px'; c.style.top = y + 'px'; };
})();
"""


def wait_for(url):
    for _ in range(120):
        try:
            urllib.request.urlopen(url, timeout=1)
            return
        except Exception:
            time.sleep(0.5)
    raise RuntimeError(f"{url} never came up")


def make_pdf(path):
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas
    c = canvas.Canvas(str(path), pagesize=A4)
    c.drawString(72, 780, "Module 1: Propositional Logic and Proofs")
    c.drawString(72, 760, "Topics: truth tables, logical equivalence, rules of inference, predicates and quantifiers.")
    c.save()


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    tmp = Path(tempfile.mkdtemp(prefix="portal-rec-"))
    pdf = tmp / "maths_module1.pdf"
    make_pdf(pdf)
    env = {**os.environ, "PORTAL_URL": f"http://127.0.0.1:{PORTAL_PORT}", "PORTAL_CACHE_DIR": str(tmp / "cache"),
           "PORTAL_NOTES_DIR": str(tmp / "notes"), "PORTAL_UPLOAD_DIR": str(tmp / "uploads"), "PORTAL_PORT": WEB_PORT, "PORT": PORTAL_PORT}
    # Re-recording with the real Claude later? Set BEDROCK_MODEL_ID before running and delete the next line.
    env.pop("BEDROCK_MODEL_ID", None)
    procs = [subprocess.Popen([sys.executable, "-m", "mock_portal.app"], cwd=ROOT, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)]
    marks = []
    t0 = [None]

    def mark(label):
        marks.append((time.time() - t0[0], label))

    try:
        wait_for(f"http://127.0.0.1:{PORTAL_PORT}/login")
        procs.append(subprocess.Popen([sys.executable, "-m", "web.app"], cwd=ROOT, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
        wait_for(f"http://127.0.0.1:{WEB_PORT}/api/health")

        from playwright.sync_api import sync_playwright
        with sync_playwright() as p:
            b = p.chromium.launch()
            ctx = b.new_context(viewport={"width": 1920, "height": 1080}, device_scale_factor=1,
                                record_video_dir=str(tmp / "vid"), record_video_size={"width": 1920, "height": 1080})
            page = ctx.new_page()
            page.goto(f"http://127.0.0.1:{WEB_PORT}/")
            page.wait_for_selector(".msg.bot")
            page.add_style_tag(content=f"html {{ zoom: {ZOOM}; }}")
            page.evaluate(CURSOR_JS)
            t0[0] = time.time()

            def point(sel):
                box = page.locator(sel).first.bounding_box()
                page.evaluate("([x,y]) => window.__moveCur(x,y)", [box["x"] + box["width"] / 2, box["y"] + box["height"] / 2])
                page.wait_for_timeout(700)

            def count_bot():
                return page.evaluate("document.querySelectorAll('.msg.bot:not(.wait)').length")

            def ask_typed(question, read_secs=5):
                n = count_bot()
                point("#q")
                page.click("#q")
                page.type("#q", question, delay=90)
                page.wait_for_timeout(500)
                point("#send")
                page.click("#send")
                page.wait_for_function(f"document.querySelectorAll('.msg.bot:not(.wait)').length > {n}")
                page.wait_for_timeout(read_secs * 1000)

            def ask_chip(text, read_secs=5):
                n = count_bot()
                point(f"text={text}")
                page.click(f"text={text}")
                page.wait_for_function(f"document.querySelectorAll('.msg.bot:not(.wait)').length > {n}")
                page.wait_for_timeout(read_secs * 1000)

            page.wait_for_timeout(3500)
            mark("beat 1: can I skip (portal + timetable)")
            ask_typed("Can I skip tomorrow?", 11)
            mark("beat 2: anything due (classroom + gmail in parallel)")
            ask_chip("Anything due this week?", 11)
            mark("beat 3: share a PDF into notes")
            point("#file")
            page.set_input_files("#file", str(pdf))
            page.wait_for_timeout(600)
            point("#subject"); page.fill("#subject", "Maths")
            point("#module"); page.fill("#module", "Module 1")
            page.wait_for_timeout(500)
            point("text=Save to Portal")
            page.click("text=Save to Portal")
            page.wait_for_function("document.getElementById('uploadMsg').textContent.startsWith('Saved')")
            page.wait_for_timeout(3500)
            mark("beat 4: ask about the PDF")
            ask_typed("What does my maths material say about inference?", 11)
            mark("beat 5: internals / SGPA (calculator, not the AI)")
            ask_chip("What do I need in my next internal?", 11)
            mark("beat 6: morning briefing")
            ask_chip("Morning briefing", 14)
            mark("end")
            vid_path = page.video.path()
            ctx.close()
            b.close()

        raw = Path(vid_path)
        mp4 = OUT / "demo.mp4"
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(raw), "-c:v", "libx264", "-preset", "veryfast",
                        "-crf", "20", "-pix_fmt", "yuv420p", "-r", "30", str(mp4)], check=True)
        (OUT / "timeline.txt").write_text("\n".join(f"{t:6.1f}s  {l}" for t, l in marks) + "\n")
        print("saved", mp4)
        print((OUT / "timeline.txt").read_text())
    finally:
        for pr in procs:
            pr.terminate()
        shutil.rmtree(tmp, ignore_errors=True)


main()
