"""One command to start everything for a live demo:  python scripts/run_demo.py
Starts the fake college site, then the Portal page, prints the address, and stops both on Ctrl-C.
(Set BEDROCK_MODEL_ID + AWS_REGION first to use the real Claude instead of the demo brain.)"""
import os
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def wait_for(url, name):
    for _ in range(120):
        try:
            urllib.request.urlopen(url, timeout=1)
            return
        except Exception:
            time.sleep(0.5)
    raise SystemExit(f"{name} did not start. Run it by hand to see the error.")


env = {**os.environ, "PORTAL_URL": "http://127.0.0.1:5000", "PORTAL_PORT": "8000", "PORT": "5000"}
procs = [subprocess.Popen([sys.executable, "-m", "mock_portal.app"], cwd=ROOT, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)]
try:
    wait_for("http://127.0.0.1:5000/login", "fake college site")
    procs.append(subprocess.Popen([sys.executable, "-m", "web.app"], cwd=ROOT, env=env))
    wait_for("http://127.0.0.1:8000/api/health", "Portal page")
    print("\nPortal is running.  Open  http://127.0.0.1:8000   (Ctrl-C to stop)\n")
    procs[-1].wait()
except KeyboardInterrupt:
    pass
finally:
    for p in procs:
        p.terminate()
