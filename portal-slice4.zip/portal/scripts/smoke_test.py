"""End-to-end check through a REAL MCP client: mock portal -> Playwright adapter -> MCP server -> tool calls.

Run from the project root:  python scripts/smoke_test.py
"""
import asyncio
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

ROOT = Path(__file__).resolve().parent.parent
PORT = "5057"


def wait_for(url, tries=40):
    for _ in range(tries):
        try:
            urllib.request.urlopen(url, timeout=1)
            return
        except Exception:
            time.sleep(0.25)
    raise RuntimeError(f"{url} never came up")


def payload(result):
    return json.loads(result.content[0].text)


async def main():
    cache_dir = tempfile.mkdtemp(prefix="portal-cache-")
    portal = subprocess.Popen([sys.executable, "-m", "mock_portal.app"], cwd=ROOT, env={**os.environ, "PORT": PORT},
                              stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        wait_for(f"http://127.0.0.1:{PORT}/login")
        env = {**os.environ, "PORTAL_URL": f"http://127.0.0.1:{PORT}", "PORTAL_CACHE_DIR": cache_dir, "PYTHONPATH": str(ROOT)}
        params = StdioServerParameters(command=sys.executable, args=["-m", "servers.portal_server"], cwd=str(ROOT), env=env)
        async with stdio_client(params) as (r, w):
            async with ClientSession(r, w) as s:
                await s.initialize()
                tools = [t.name for t in (await s.list_tools()).tools]
                print("TOOLS:", tools)
                assert {"get_attendance", "get_timetable", "get_internal_marks", "can_i_skip", "cgpa_target_plan"} <= set(tools)

                att = payload(await s.call_tool("get_attendance", {"subject": "Operating"}))
                print("\nATTENDANCE (OS):", json.dumps(att, indent=1))
                assert att["subjects"][0]["percent"] == 74.0 and att["stale"] is False

                skip = payload(await s.call_tool("can_i_skip", {"day": "Mon"}))
                print("\nCAN I SKIP (Monday):", skip["summary"])
                assert skip["overall_verdict"] == "no"

                marks = payload(await s.call_tool("get_internal_marks", {}))
                assert marks["subjects"][0]["ia"] == [18.0, None]

                plan = payload(await s.call_tool("cgpa_target_plan", {"target_cgpa": 8.0}))
                print("\nCGPA PLAN (SGPA 8.0, SEE 60%):", plan["note"], "| achievable:", plan["achievable"], "| plan SGPA:", plan["sgpa_with_this_plan"])
                for row in plan["subjects"]:
                    print(f"   {row['name']:<30} aim {row['target_grade']:<2} need {row['extra_internal_marks_needed']:>4.0f}/{row['out_of_remaining_internals']:.0f} in IA2")

                # Reliability: kill the portal and make sure we still answer from cache, flagged stale.
                portal.terminate(); portal.wait()
                stale = payload(await s.call_tool("get_attendance", {}))
                print("\nPORTAL DOWN ->", "stale:", stale["stale"], "|", stale.get("warning"))
                assert stale["stale"] is True and len(stale["subjects"]) == 6
        print("\nALL SMOKE CHECKS PASSED")
    finally:
        if portal.poll() is None:
            portal.terminate()
        shutil.rmtree(cache_dir, ignore_errors=True)


asyncio.run(main())
