"""Person C: run this once your AWS setup is done. It proves the REAL Claude works with Portal's tools.

    (Windows)                          (Mac / Linux)
    set AWS_REGION=your-region         export AWS_REGION=your-region
    set BEDROCK_MODEL_ID=model-id      export BEDROCK_MODEL_ID=model-id
    python scripts/test_bedrock.py

Needs:  pip install boto3   and   aws configure   (from Step 1).
NOTE: this file could not be run by the person who wrote it (no AWS keys there). If it fails, send the exact error
text (with any keys removed) and it will get fixed.
"""
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from agent.llm import BedrockLLM  # noqa: E402

TOOLS = [{
    "name": "can_i_skip",
    "description": "Check attendance and say whether the student can skip classes on a day.",
    "input_schema": {"type": "object", "properties": {"day": {"type": "string", "description": "today, tomorrow, or a weekday"}}},
}]


async def main():
    llm = BedrockLLM()
    print("Test 1: plain hello (no tools)")
    out = await llm.generate("You are a friendly assistant.", [{"role": "user", "content": [{"text": "Say hello in one short sentence."}]}], [])
    print("   ->", out["message"]["content"][0]["text"])

    print("Test 2: does Claude ask to use our tool?")
    out = await llm.generate("You are Portal. Use tools for facts.", [{"role": "user", "content": [{"text": "Can I skip tomorrow?"}]}], TOOLS)
    uses = [b["toolUse"] for b in out["message"]["content"] if "toolUse" in b]
    print("   stop reason:", out["stop_reason"], "| tool requests:", uses)
    if not uses:
        sys.exit("FAIL: Claude did not ask to use the tool.")
    print("\nBEDROCK WORKS WITH PORTAL'S TOOL FORMAT. Next: python -m agent.cli")


asyncio.run(main())
