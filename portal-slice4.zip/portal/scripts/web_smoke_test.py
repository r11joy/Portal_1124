"""Opens the real web page in a real (headless) browser and uses it like a person would. No AWS needed.

Run from the project root:  python scripts/web_smoke_test.py [screenshot_folder]
"""
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SHOTS = Path(sys.argv[1]) if len(sys.argv) > 1 else None
PORTAL_PORT, WEB_PORT = "5059", "8001"


def wait_for(url):
    for _ in range(120):
        try:
            urllib.request.urlopen(url, timeout=1)
            return
        except Exception:
            time.sleep(0.5)
    raise RuntimeError(f"{url} never came up")


def check(cond, label):
    print(("  PASS  " if cond else "  FAIL  ") + label)
    if not cond:
        raise SystemExit(1)


def post_json(path, body):
    req = urllib.request.Request(f"http://127.0.0.1:{WEB_PORT}{path}", json.dumps(body).encode(), {"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return r.status, json.load(r)
    except urllib.error.HTTPError as e:
        return e.code, json.load(e)


def make_pdf(path):
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas
    c = canvas.Canvas(str(path), pagesize=A4)
    c.drawString(72, 780, "Module 1: Propositional Logic and Proofs")
    c.drawString(72, 760, "Topics: truth tables, logical equivalence, rules of inference, predicates and quantifiers.")
    c.save()


def main():
    tmp = Path(tempfile.mkdtemp(prefix="portal-web-test-"))
    pdf = tmp / "maths_module1.pdf"
    make_pdf(pdf)
    env = {**os.environ, "PORTAL_URL": f"http://127.0.0.1:{PORTAL_PORT}", "PORTAL_CACHE_DIR": str(tmp / "cache"),
           "PORTAL_NOTES_DIR": str(tmp / "notes"), "PORTAL_UPLOAD_DIR": str(tmp / "uploads"), "PORTAL_PORT": WEB_PORT, "PORT": PORTAL_PORT}
    env.pop("BEDROCK_MODEL_ID", None)
    procs = [subprocess.Popen([sys.executable, "-m", "mock_portal.app"], cwd=ROOT, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)]
    try:
        wait_for(f"http://127.0.0.1:{PORTAL_PORT}/login")
        procs.append(subprocess.Popen([sys.executable, "-m", "web.app"], cwd=ROOT, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
        wait_for(f"http://127.0.0.1:{WEB_PORT}/api/health")

        print("1. The API")
        code, h = post_json("/api/ask", {"question": ""})
        check(code == 400 and "error" in h, "empty question is refused politely (400)")
        code, h = post_json("/api/ask", {"question": "x" * 2000})
        check(code == 400, "absurdly long question is refused")
        code, d = post_json("/api/ask", {"question": "Can I skip tomorrow?"})
        check(code == 200 and "Don't skip" in d["answer"] and d["trace"][0]["tool"] == "can_i_skip", "'Can I skip tomorrow?' answered with a trace")
        code, d = post_json("/api/briefing", {})
        check(code == 200 and d["answer"].startswith("Good morning") and len(d["trace"]) == 4, "morning briefing runs 4 tools and says good morning")
        print("   ->", d["answer"][:300])

        print("2. The page, driven by a real browser")
        from playwright.sync_api import sync_playwright
        with sync_playwright() as p:
            b = p.chromium.launch()
            page = b.new_page(viewport={"width": 1280, "height": 860}, device_scale_factor=1)
            errors = []
            page.on("pageerror", lambda e: errors.append(str(e)))
            page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
            page.goto(f"http://127.0.0.1:{WEB_PORT}/")
            page.wait_for_selector(".msg.bot")
            check("Demo brain" in page.inner_text("#brain"), "page says which brain is answering")

            page.click("text=Anything due this week?")
            page.wait_for_function("document.querySelectorAll('.msg.bot:not(.wait)').length >= 2")
            rows = page.query_selector_all("#trace .row")
            check(len(rows) == 2 and "parallel" in page.inner_text("#traceNote"), "two servers shown, with the 'ran in parallel' note")

            page.set_input_files("#file", str(pdf))
            page.fill("#subject", "Maths")
            page.fill("#module", "Module 1")
            page.click("text=Save to Portal")
            page.wait_for_function("document.getElementById('uploadMsg').textContent.startsWith('Saved')")
            check(True, "PDF uploaded through the form and saved")

            page.fill("#q", "What does my maths material say about inference?")
            page.click("#send")
            page.wait_for_function("[...document.querySelectorAll('.msg.bot')].some(m => m.textContent.includes('inference') && m.textContent.includes('Found in'))")
            check(True, "asked about the uploaded PDF and got text from inside it")

            page.click("text=Morning briefing")
            page.wait_for_function("[...document.querySelectorAll('.msg.bot')].some(m => m.textContent.startsWith('Good morning'))")
            if SHOTS:
                SHOTS.mkdir(parents=True, exist_ok=True)
                page.screenshot(path=str(SHOTS / "web-desktop.png"))
            check(len(page.query_selector_all("#trace .row")) == 4, "briefing trace shows 4 tool calls")

            m = b.new_page(viewport={"width": 390, "height": 800}, device_scale_factor=2)
            m.goto(f"http://127.0.0.1:{WEB_PORT}/")
            m.wait_for_selector(".msg.bot")
            overflow = m.evaluate("document.documentElement.scrollWidth > document.documentElement.clientWidth")
            check(not overflow, "phone width: no sideways scrolling")
            if SHOTS:
                m.screenshot(path=str(SHOTS / "web-phone.png"))
            check(not errors, f"no errors in the browser console {errors[:2] if errors else ''}")
            b.close()
        print("\nALL WEB CHECKS PASSED")
    finally:
        for pr in procs:
            pr.terminate()
        shutil.rmtree(tmp, ignore_errors=True)


main()
