"""Google Classroom MCP server (STAND-IN with fake data).

THE CONTRACT (Person B: your real version must return exactly these shapes, so nothing else has to change):
  get_assignments(course?, due_within_days?) -> {source, synced_at, stale, content_trust, assignments:[
        {course, title, due (ISO datetime), days_left (int), status ('assigned'|'turned_in')}]}
  get_announcements(course?, limit?)         -> {..., announcements:[{course, text, posted (ISO datetime)}]}
  get_course_materials(course?)              -> {..., materials:[{course, title, type, link}]}
  find_deadline_clashes(window_hours?, min_items?) -> {..., clashes:[{count, first_due, last_due, span_hours, items:[...]}]}  (works on top of your assignments loader, nothing to change)
Replace the DATA SOURCE section with calls to the Google Classroom API (read-only scopes). Keep the tools.

Run (stdio):  python -m servers.classroom_server
"""
from __future__ import annotations

import logging
import sys
from datetime import datetime, timezone
from typing import Optional

try:
    from fastmcp import FastMCP
except ImportError:
    try:
        from mcp.server.fastmcp import FastMCP
    except ImportError:
        from mcp.server.mcpserver import MCPServer as FastMCP

from mock_google import data
from portal_core import clash, dates

logging.basicConfig(stream=sys.stderr, level=logging.INFO)
mcp = FastMCP("google-classroom")
SOURCE = "Google Classroom (stand-in data)"


def _meta(**extra) -> dict:
    return {"source": SOURCE, "synced_at": datetime.now(timezone.utc).isoformat(timespec="seconds"), "stale": False,
            "content_trust": "untrusted", **extra}


def _course_ok(query: Optional[str], course: str) -> bool:
    return not query or query.lower() in course.lower()


# ============================== DATA SOURCE (Person B replaces this part with the real Google API) ==============
def _load_assignments() -> list[dict]:
    now = datetime.now(dates.TZ)
    out = []
    for a in data.ASSIGNMENTS:
        due = dates.next_weekday(*a["due"])
        out.append({"course": a["course"], "title": a["title"], "due": due.isoformat(timespec="minutes"),
                    "days_left": (due.date() - now.date()).days, "status": a["status"]})
    return out


def _load_announcements() -> list[dict]:
    return [{"course": a["course"], "text": a["text"], "posted": dates.days_ago(a["days_ago"]).isoformat(timespec="minutes")}
            for a in data.ANNOUNCEMENTS]


def _load_materials() -> list[dict]:
    return list(data.MATERIALS)
# ================================================================================================================


@mcp.tool()
def get_assignments(course: Optional[str] = None, due_within_days: Optional[int] = None) -> dict:
    """Assignments from Google Classroom with due dates and whether they're turned in. Optionally filter by course
    name, or by 'due within N days'. Sorted by due date, soonest first."""
    rows = [a for a in _load_assignments() if _course_ok(course, a["course"])]
    if due_within_days is not None:
        rows = [a for a in rows if a["days_left"] <= due_within_days]
    return _meta(assignments=sorted(rows, key=lambda a: a["due"]))


@mcp.tool()
def find_deadline_clashes(window_hours: int = 48, min_items: int = 2) -> dict:
    """Finds crunch periods: groups of not-yet-submitted Classroom assignments due within window_hours of each other
    (default 48). Use for 'is any week too busy?', 'do my deadlines clash?', 'what should I start first?'."""
    groups = clash.find_clashes(_load_assignments(), window_hours, min_items)
    return _meta(window_hours=window_hours, clashes=groups)


@mcp.tool()
def get_announcements(course: Optional[str] = None, limit: int = 5) -> dict:
    """Latest teacher announcements from Google Classroom, newest first. Optionally filter by course name."""
    rows = [a for a in _load_announcements() if _course_ok(course, a["course"])]
    return _meta(announcements=sorted(rows, key=lambda a: a["posted"], reverse=True)[:limit])


@mcp.tool()
def get_course_materials(course: Optional[str] = None) -> dict:
    """Files and links teachers shared in Classroom. Optionally filter by course name."""
    return _meta(materials=[m for m in _load_materials() if _course_ok(course, m["course"])])


if __name__ == "__main__":
    mcp.run(transport="stdio")
