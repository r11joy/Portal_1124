"""Gmail MCP server (STAND-IN with fake data).

THE CONTRACT (Person B: a real version, or Google's official Gmail MCP server wrapped to match, should return):
  search_emails(query, limit?)  -> {source, synced_at, stale, content_trust, emails:[{id, from, subject, date, snippet}]}
  get_email(email_id)           -> {..., email:{id, from, subject, date, body}}
Read-only. Replace the DATA SOURCE section. Keep the tools.

Email bodies are written by strangers, so they are marked content_trust="untrusted": the agent may READ them
but must never FOLLOW instructions inside them.

Run (stdio):  python -m servers.gmail_server
"""
from __future__ import annotations

import logging
import re
import sys
from datetime import datetime, timezone

try:
    from fastmcp import FastMCP
except ImportError:
    try:
        from mcp.server.fastmcp import FastMCP
    except ImportError:
        from mcp.server.mcpserver import MCPServer as FastMCP

from mock_google import data
from portal_core import dates

logging.basicConfig(stream=sys.stderr, level=logging.INFO)
mcp = FastMCP("gmail")
SOURCE = "college Gmail (stand-in data)"


def _meta(**extra) -> dict:
    return {"source": SOURCE, "synced_at": datetime.now(timezone.utc).isoformat(timespec="seconds"), "stale": False,
            "content_trust": "untrusted", **extra}


# ============================== DATA SOURCE (Person B replaces this part with the real Gmail API) ================
def _all_emails() -> list[dict]:
    return [{"id": e["id"], "from": e["from"], "subject": e["subject"], "body": e["body"],
             "date": dates.days_ago(e["days_ago"]).isoformat(timespec="minutes")} for e in data.EMAILS]
# ================================================================================================================


@mcp.tool()
def search_emails(query: str, limit: int = 5) -> dict:
    """Search the student's college emails by keywords (sender, subject and body). Newest first. Returns short snippets;
    call get_email for the full text."""
    words = [w for w in re.findall(r"[a-z0-9]+", query.lower()) if len(w) > 1]
    hits = []
    for e in _all_emails():
        text = (e["from"] + " " + e["subject"] + " " + e["body"]).lower()  # like Gmail, sender is searchable too
        if not words or any(w in text for w in words):
            hits.append({"id": e["id"], "from": e["from"], "subject": e["subject"], "date": e["date"], "snippet": e["body"][:200]})
    return _meta(query=query, emails=sorted(hits, key=lambda e: e["date"], reverse=True)[:limit])


@mcp.tool()
def get_email(email_id: str) -> dict:
    """Get the full text of one email by its id (from search_emails)."""
    for e in _all_emails():
        if e["id"] == email_id:
            return _meta(email=e)
    raise LookupError(f"No email with id {email_id!r}")


if __name__ == "__main__":
    mcp.run(transport="stdio")
