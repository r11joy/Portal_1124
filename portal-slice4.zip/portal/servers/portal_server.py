"""College Portal MCP server.

Run (stdio):  python -m servers.portal_server
Every answer carries its source and when it was synced, and falls back to cached data (flagged stale) if the
portal is down. All math is done by portal_core.calc, never by the LLM.

NOTE: works with the standalone `fastmcp` package or the official `mcp` SDK (v1 or v2); same decorator API.
"""
from __future__ import annotations

import logging
import sys
from datetime import date, datetime, timedelta
from typing import Optional
from zoneinfo import ZoneInfo

try:  # the standalone package the team will `pip install fastmcp`
    from fastmcp import FastMCP
except ImportError:
    try:  # official SDK v1
        from mcp.server.fastmcp import FastMCP
    except ImportError:  # official SDK v2 renamed it
        from mcp.server.mcpserver import MCPServer as FastMCP

from portal_core import cache, calc
from portal_core.adapters import build_adapter

logging.basicConfig(stream=sys.stderr, level=logging.INFO)  # stdout is reserved for MCP traffic
log = logging.getLogger("portal-server")

TZ = ZoneInfo("Asia/Kolkata")
mcp = FastMCP("college-portal")
adapter = build_adapter()
SOURCE = f"college portal ({adapter.name})"


async def _get(key: str, fetcher):
    """Fetch live, cache it; on failure serve the cached copy marked stale."""
    try:
        data = await fetcher()
        return {"data": data, "source": SOURCE, "synced_at": cache.save(key, data), "stale": False}
    except Exception as exc:  # noqa: BLE001
        log.warning("live fetch of %s failed: %r", key, exc)
        cached = cache.load(key)
        if cached is None:
            raise RuntimeError(f"Could not reach the college portal and nothing is cached yet: {exc}") from exc
        synced_at, data = cached
        return {"data": data, "source": SOURCE, "synced_at": synced_at, "stale": True,
                "warning": "Portal unreachable right now. This is the last saved copy."}


def _envelope(base: dict, **extra) -> dict:
    out = {k: base[k] for k in ("source", "synced_at", "stale") if k in base}
    if base.get("warning"):
        out["warning"] = base["warning"]
    out.update(extra)
    return out


def _resolve_day(day: Optional[str]) -> tuple[date, str]:
    """'today' | 'tomorrow' | 'Mon'/'monday' | 'YYYY-MM-DD'  ->  (date, 'Mon')."""
    today = datetime.now(TZ).date()
    d = (day or "today").strip().lower()
    if d == "today":
        target = today
    elif d == "tomorrow":
        target = today + timedelta(days=1)
    elif len(d) >= 3 and d[:3] in ("mon", "tue", "wed", "thu", "fri", "sat", "sun"):
        names = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"]
        target = today + timedelta(days=(names.index(d[:3]) - today.weekday()) % 7)
    else:
        target = date.fromisoformat(d)
    return target, target.strftime("%a")


@mcp.tool()
async def get_attendance(subject: Optional[str] = None) -> dict:
    """Live attendance per subject: classes attended, classes held, percentage, and how many classes can still
    be missed (or must be attended to recover) against the 75% rule. Pass a subject name or code to filter."""
    base = await _get("attendance", adapter.fetch_attendance)
    rows = []
    for r in base["data"]:
        if subject and subject.lower() not in (r["code"].lower(), r["name"].lower()) and subject.lower() not in r["name"].lower():
            continue
        rows.append({
            "code": r["code"], "name": r["name"], "attended": r["attended"], "held": r["held"],
            "percent": calc.percent(r["attended"], r["held"]),
            "spare_classes_before_75": calc.skippable(r["attended"], r["held"]),
            "classes_to_attend_to_reach_75": calc.classes_needed(r["attended"], r["held"]),
        })
    return _envelope(base, threshold=calc.ATTENDANCE_THRESHOLD, subjects=rows)


@mcp.tool()
async def get_timetable(day: Optional[str] = None) -> dict:
    """The class timetable for a day ('today', 'tomorrow', a weekday like 'Wed', or YYYY-MM-DD).
    Returns subject codes and names in period order."""
    tt = await _get("timetable", adapter.fetch_timetable)
    att = await _get("attendance", adapter.fetch_attendance)
    names = {r["code"]: r["name"] for r in att["data"]}
    target, wd = _resolve_day(day)
    codes = tt["data"].get(wd, [])
    return _envelope(tt, date=target.isoformat(), weekday=wd,
                     classes=[{"code": c, "name": names.get(c, c)} for c in codes])


@mcp.tool()
async def get_internal_marks() -> dict:
    """Internal assessment (IA) marks per subject, out of 25 each. null means that test hasn't happened yet."""
    base = await _get("marks", adapter.fetch_marks)
    return _envelope(base, ia_max_each=calc.IA_MAX_EACH, subjects=base["data"])


@mcp.tool()
async def can_i_skip(subject: Optional[str] = None, day: Optional[str] = "today") -> dict:
    """Answer "can I bunk?". Checks live attendance against the 75% rule. With a subject, judges that subject
    for the day. With no subject, judges every class on that day's timetable and gives one overall verdict.
    The verdict is computed by code: 'ok', 'risky' (little buffer left) or 'no'."""
    att = await _get("attendance", adapter.fetch_attendance)
    tt = await _get("timetable", adapter.fetch_timetable)
    target, wd = _resolve_day(day)
    todays = tt["data"].get(wd, [])
    by_code = {r["code"]: r for r in att["data"]}

    wanted = []
    for r in att["data"]:
        if subject and subject.lower() not in (r["code"].lower(), r["name"].lower()) and subject.lower() not in r["name"].lower():
            continue
        wanted.append(r["code"])
    if subject and not wanted:
        raise ValueError(f"No subject matching {subject!r}")

    results = []
    for code in dict.fromkeys(c for c in todays if c in wanted):
        r = by_code[code]
        n = todays.count(code)
        v = calc.skip_verdict(r["attended"], r["held"], n_missed=n)
        results.append({"code": code, "name": r["name"], "classes_that_day": n, **v})

    if not results:
        overall, summary = "ok", f"No {'matching ' if subject else ''}classes on {wd} {target.isoformat()}."
    else:
        order = {"no": 2, "risky": 1, "ok": 0}
        overall = max((x["verdict"] for x in results), key=order.get)
        bad = [x["name"] for x in results if x["verdict"] == "no"]
        risky = [x["name"] for x in results if x["verdict"] == "risky"]
        summary = {
            "no": f"Don't skip: you'd be below 75% in {', '.join(bad)}.",
            "risky": f"Risky: you'd have almost no buffer left in {', '.join(risky)}.",
            "ok": "Yes, you can skip and stay at or above 75% in every class that day.",
        }[overall]
    return _envelope(att, date=target.isoformat(), weekday=wd, overall_verdict=overall, summary=summary, by_subject=results)


@mcp.tool()
async def cgpa_target_plan(target_cgpa: float, previous_cgpa: Optional[float] = None, previous_credits: Optional[int] = None,
                           assumed_see_percent: float = 60.0) -> dict:
    """"How much do I need to get X CGPA?" Uses the student's real internal marks from the portal.
    Gives, per subject, the grade to aim for and the extra internal marks needed out of what's left.
    If previous_cgpa and previous_credits are given, target_cgpa is for the overall CGPA; otherwise it is
    treated as this semester's SGPA. assumed_see_percent is the end-semester score the student expects (default 60)."""
    base = await _get("marks", adapter.fetch_marks)
    subjects = [calc.Subject(r["code"], r["name"], r["credits"], r["ia"]) for r in base["data"]]
    this_credits = sum(s.credits for s in subjects)
    if previous_cgpa is not None and previous_credits is not None:
        target_sgpa = calc.required_sgpa_for_cgpa(target_cgpa, previous_cgpa, previous_credits, this_credits)
        note = f"To reach CGPA {target_cgpa}, this semester's SGPA must be {target_sgpa:.2f}."
    else:
        target_sgpa, note = target_cgpa, "Treating the target as this semester's SGPA (no previous CGPA given)."
    if target_sgpa > 10:
        return _envelope(base, achievable=False, note=note + " That is above 10, so the target is out of reach.")
    plan = calc.plan_for_sgpa(subjects, round(target_sgpa, 2), assumed_see_percent)
    return _envelope(base, note=note, grading_scheme="VTU-style, confirm against your college's scheme", **plan)


if __name__ == "__main__":
    mcp.run(transport="stdio")
