"""The Bedrock adapter, tested with a FAKE AWS client (no keys, no network)."""
import asyncio

import pytest

from agent.llm import BedrockLLM, to_bedrock_tools

TOOLS = [{"name": "can_i_skip", "description": "Bunk check", "input_schema": {"type": "object", "properties": {"day": {"type": "string"}}}}]


class FakeClient:
    def __init__(self):
        self.kwargs = None

    def converse(self, **kwargs):
        self.kwargs = kwargs
        return {"stopReason": "tool_use", "output": {"message": {"role": "assistant", "content": [
            {"toolUse": {"toolUseId": "x", "name": "can_i_skip", "input": {"day": "today"}}}]}}}


def test_tools_are_translated_to_bedrock_shape():
    cfg = to_bedrock_tools(TOOLS)
    spec = cfg["tools"][0]["toolSpec"]
    assert spec["name"] == "can_i_skip" and spec["inputSchema"]["json"]["type"] == "object"


def test_generate_sends_the_right_request_and_returns_a_clean_result():
    fake = FakeClient()
    llm = BedrockLLM(model_id="some-model-id", client=fake)
    out = asyncio.run(llm.generate("be nice", [{"role": "user", "content": [{"text": "hi"}]}], TOOLS))
    assert fake.kwargs["modelId"] == "some-model-id"
    assert fake.kwargs["system"] == [{"text": "be nice"}]
    assert "toolConfig" in fake.kwargs and fake.kwargs["inferenceConfig"]["temperature"] == 0.2
    assert out["stop_reason"] == "tool_use" and out["message"]["content"][0]["toolUse"]["name"] == "can_i_skip"


def test_no_tools_means_no_toolconfig():
    fake = FakeClient()
    asyncio.run(BedrockLLM(model_id="m", client=fake).generate("s", [], []))
    assert "toolConfig" not in fake.kwargs


def test_missing_model_id_gives_a_clear_error(monkeypatch):
    monkeypatch.delenv("BEDROCK_MODEL_ID", raising=False)
    with pytest.raises(RuntimeError, match="BEDROCK_MODEL_ID"):
        BedrockLLM(client=FakeClient())
