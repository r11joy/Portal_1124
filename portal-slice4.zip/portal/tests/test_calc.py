import pytest

from portal_core import calc


def test_percent():
    assert calc.percent(37, 50) == 74.0
    assert calc.percent(0, 0) == 0.0


def test_skippable_exact_boundary():
    # 30/40 = 75% exactly. Missing 1 more: 30/41 = 73.2% -> no spare classes.
    assert calc.skippable(30, 40) == 0
    # 36/40 = 90%. Max k with 36/(40+k) >= .75 -> k = 8 (36/48 = 75%).
    assert calc.skippable(36, 40) == 8
    assert calc.skippable(36, 48) == 0


def test_below_threshold_skippable_is_zero():
    assert calc.skippable(37, 50) == 0  # 74%


def test_classes_needed():
    assert calc.classes_needed(36, 40) == 0
    # 37/50 = 74%. Attend m: (37+m)/(50+m) >= .75 -> m >= 1. 38/51 = 74.5%... so m=2: 39/52 = 75% exactly.
    assert calc.classes_needed(37, 50) == 2
    assert (37 + 2) / (50 + 2) >= 0.75 > (37 + 1) / (50 + 1)


def test_skip_verdict_no_ok_risky():
    assert calc.skip_verdict(37, 50, 1)["verdict"] == "no"       # already under 75 and worse after
    assert calc.skip_verdict(36, 40, 1)["verdict"] == "ok"       # lots of buffer
    assert calc.skip_verdict(30, 39, 1)["verdict"] == "risky"    # 30/40 = 75 exactly, no spare


def test_grade_bands():
    assert calc.grade_for(95) == (10, "O")
    assert calc.grade_for(80) == (9, "A+")
    assert calc.grade_for(79.9) == (8, "A")
    assert calc.grade_for(39) == (0, "F")


def test_required_sgpa_for_cgpa():
    # Prev: 7.6 over 100 credits. Want 8.0 after 20 more credits -> need (8*120 - 7.6*100)/20 = 10.0
    assert calc.required_sgpa_for_cgpa(8.0, 7.6, 100, 20) == pytest.approx(10.0)


def _subjects():
    return [
        calc.Subject("A", "A", 4, [20, None]),
        calc.Subject("B", "B", 4, [10, None]),
        calc.Subject("C", "C", 2, [25, None]),
    ]


def test_plan_reaches_reasonable_target_and_is_consistent():
    plan = calc.plan_for_sgpa(_subjects(), 7.5, assumed_see_percent=60)
    assert plan["achievable"] is True
    assert plan["sgpa_with_this_plan"] >= 7.5
    for row in plan["subjects"]:
        assert 0 <= row["extra_internal_marks_needed"] <= row["out_of_remaining_internals"]


def test_plan_best_case_is_hand_checked():
    # SEE 60% -> 30 scaled. Best case totals: A 20+25+30=75 (A,8), B 10+25+30=65 (B+,7), C 25+25+30=80 (A+,9).
    # SGPA = (4*8 + 4*7 + 2*9) / 10 = 7.8, so 8.0 is out of reach and the plan must say so.
    plan = calc.plan_for_sgpa(_subjects(), 8.0, assumed_see_percent=60)
    assert plan["achievable"] is False
    assert plan["sgpa_with_this_plan"] == 7.8


def test_plan_reports_infeasible_target():
    # SEE assumed 0% and a 10 SGPA is impossible
    plan = calc.plan_for_sgpa(_subjects(), 10.0, assumed_see_percent=0)
    assert plan["achievable"] is False


def test_plan_needed_marks_are_exact():
    # Single subject, IA1=20, SEE assumed 60% -> 30 scaled. Total so far 50 + IA2.
    # To get A (70 total) need IA2 >= 20.
    s = [calc.Subject("X", "X", 4, [20, None])]
    plan = calc.plan_for_sgpa(s, 8.0, assumed_see_percent=60)
    row = plan["subjects"][0]
    assert row["target_grade"] == "A"
    assert row["extra_internal_marks_needed"] == 20
