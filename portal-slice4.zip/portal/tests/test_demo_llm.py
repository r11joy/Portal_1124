import asyncio

from agent.demo_llm import DemoLLM, _plan

TOOLS = [{"name": n, "description": "", "input_schema": {}} for n in
         ["can_i_skip", "get_attendance", "get_timetable", "get_assignments", "search_emails", "search_notes", "cgpa_target_plan",
          "get_announcements", "list_notes", "get_note", "save_note"]]


def names(q):
    return [c["toolUse"]["name"] for c in _plan(q.lower())]


def test_routing():
    assert names("Can I skip tomorrow?") == ["can_i_skip"]
    assert names("Do I have anything due this week?") == ["get_assignments", "search_emails"]
    assert names("What's my attendance in OS?") == ["get_attendance"]
    assert names("Play my morning briefing") == ["get_timetable", "get_attendance", "get_assignments", "cgpa_target_plan"]
    assert names("What topics are in my maths notes?") == ["search_notes"]
    assert names("What does my maths material say about inference?") == ["search_notes"]


def test_skip_picks_subject_and_day():
    c = _plan("can i bunk os on friday?")[0]["toolUse"]["input"]
    assert c == {"day": "friday", "subject": "Operating"}


def test_unknown_question_gets_a_helpful_answer_not_a_crash():
    out = asyncio.run(DemoLLM().generate("", [{"role": "user", "content": [{"text": "write me a poem"}]}], TOOLS))
    assert out["stop_reason"] == "end_turn" and "demo brain" in out["message"]["content"][0]["text"].lower()


def test_tools_the_server_does_not_have_are_not_called():
    out = asyncio.run(DemoLLM().generate("", [{"role": "user", "content": [{"text": "can i skip?"}]}], []))
    assert out["stop_reason"] == "end_turn"
