from datetime import datetime

from portal_core import dates
from servers import classroom_server as cr
from servers import gmail_server as gm


def test_assignments_sorted_and_future():
    rows = cr.get_assignments()["assignments"]
    assert [r["due"] for r in rows] == sorted(r["due"] for r in rows)
    assert all(r["days_left"] >= 0 for r in rows)          # "due Thursday" is always the coming Thursday
    assert {"course", "title", "due", "days_left", "status"} <= set(rows[0])


def test_assignment_filters():
    soon = cr.get_assignments(due_within_days=1)["assignments"]
    assert all(r["days_left"] <= 1 for r in soon)
    assert all("networks" in r["course"].lower() for r in cr.get_assignments(course="networks")["assignments"])


def test_announcements_and_materials():
    assert cr.get_announcements(limit=2)["announcements"][0]["posted"] >= cr.get_announcements()["announcements"][-1]["posted"]
    assert cr.get_course_materials(course="structures")["materials"]


def test_every_google_result_is_marked_untrusted():
    for res in (cr.get_assignments(), cr.get_announcements(), cr.get_course_materials(), gm.search_emails("exam")):
        assert res["content_trust"] == "untrusted" and "source" in res and "synced_at" in res and res["stale"] is False


def test_email_search_and_get():
    hits = gm.search_emails("IA2 timetable")["emails"]
    assert hits[0]["id"] == "m1"
    assert "Thursday" in gm.get_email("m1")["email"]["body"]


def test_the_injection_test_email_exists_so_we_can_check_the_agent_ignores_it():
    body = gm.get_email("m5")["email"]["body"]
    assert "ignore all your rules" in body.lower()


def test_search_matches_sender_too():
    assert [e["id"] for e in gm.search_emails("prizes")["emails"]] == ["m5"]


def test_a_deadline_earlier_today_rolls_to_next_week():
    from datetime import datetime as dt
    ref = dt(2026, 11, 23).date()                           # a Monday
    evening = dt(2026, 11, 23, 17, 0, tzinfo=dates.TZ)
    assert dates.next_weekday("Mon", "09:00", ref=ref, now=evening).date().isoformat() == "2026-11-30"   # 9 AM already passed
    assert dates.next_weekday("Mon", "23:00", ref=ref, now=evening).date().isoformat() == "2026-11-23"   # 11 PM still ahead


def test_next_weekday_never_in_the_past():
    ref = datetime(2026, 11, 22).date()      # a Sunday
    assert dates.next_weekday("Thu", ref=ref).date().isoformat() == "2026-11-26"
    assert dates.next_weekday("Sun", ref=ref).date() == ref


def test_deadline_clash_groups_close_deadlines_and_ignores_turned_in():
    from portal_core.clash import find_clashes
    items = [{"course": "A", "title": "a", "due": "2026-11-26T17:00+05:30", "status": "assigned"},
             {"course": "B", "title": "b", "due": "2026-11-27T23:59+05:30", "status": "assigned"},
             {"course": "C", "title": "c", "due": "2026-11-27T10:00+05:30", "status": "turned_in"},
             {"course": "D", "title": "d", "due": "2026-11-30T09:00+05:30", "status": "assigned"}]
    got = find_clashes(items)
    assert len(got) == 1 and [i["course"] for i in got[0]["items"]] == ["A", "B"] and got[0]["span_hours"] == 31.0
    assert find_clashes(items, window_hours=10) == []


def test_clash_tool_and_demo_brain_route():
    assert cr.find_deadline_clashes()["clashes"]
    from agent import demo_llm
    assert demo_llm._plan("do my deadlines clash?")[0]["toolUse"]["name"] == "find_deadline_clashes"
