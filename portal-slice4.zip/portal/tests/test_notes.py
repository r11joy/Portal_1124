import pytest

from portal_core.notes import NoteStore, subject_matches


@pytest.fixture
def pdf(tmp_path):
    reportlab = pytest.importorskip("reportlab")
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas

    path = tmp_path / "maths_m1.pdf"
    c = canvas.Canvas(str(path), pagesize=A4)
    c.drawString(72, 780, "Module 1: Propositional Logic and Proofs")
    c.drawString(72, 760, "Topics: truth tables, logical equivalence, predicates and quantifiers.")
    c.showPage()
    c.drawString(72, 780, "Rules of inference and methods of proof: direct proof, contradiction, induction.")
    c.showPage()
    c.save()
    return path


def test_subject_matching_is_forgiving():
    assert subject_matches("maths", "Discrete Mathematics")
    assert subject_matches("OS", "OS")
    assert not subject_matches("maths", "Operating Systems")
    assert subject_matches("computer networks", "Computer Networks")


def test_save_search_get_roundtrip(tmp_path, pdf):
    s = NoteStore(tmp_path / "store")
    saved = s.save("Discrete Mathematics", "Module 1", file_path=str(pdf))
    assert saved["pages"] == 2 and saved["file"].endswith(".pdf")

    hit = s.search("what is rules of inference")[0]
    assert hit["page"] == 2 and "inference" in hit["snippet"].lower()

    got = s.get("maths", "module 1")["notes"][0]
    assert "truth tables" in got["text"] and got["id"] == saved["id"]


def test_module_number_matching_and_missing(tmp_path, pdf):
    s = NoteStore(tmp_path / "store")
    s.save("Maths", "Module 1", file_path=str(pdf))
    assert s.get("maths", "1")["notes"]          # "1" matches "Module 1"
    with pytest.raises(LookupError):
        s.get("maths", "Module 4")               # honest "not saved", not a guess
    with pytest.raises(LookupError):
        s.get("physics")


def test_persists_between_runs(tmp_path, pdf):
    NoteStore(tmp_path / "store").save("Maths", "Module 1", file_path=str(pdf))
    again = NoteStore(tmp_path / "store")
    assert len(again.list()) == 1


def test_bad_inputs(tmp_path):
    s = NoteStore(tmp_path / "store")
    with pytest.raises(ValueError):
        s.save("", "Module 1", text="x")
    with pytest.raises(ValueError):
        s.save("Maths", "Module 1")
    with pytest.raises(FileNotFoundError):
        s.save("Maths", "Module 1", file_path=str(tmp_path / "nope.pdf"))
