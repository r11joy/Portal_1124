"""The web server: a small Flask app that puts the agent behind a web page.

Run:  python -m web.app          then open http://127.0.0.1:8000
It uses real Claude on Bedrock if BEDROCK_MODEL_ID is set, otherwise the offline demo brain (and says so on screen).
It listens on this computer only (127.0.0.1) unless you set PORTAL_HOST, so nobody else on the WiFi can use it.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import tempfile
import threading
from pathlib import Path

from flask import Flask, jsonify, request, send_from_directory
from werkzeug.utils import secure_filename

from agent.core import PortalAgent
from agent.demo_llm import DemoLLM

log = logging.getLogger("portal-web")
STATIC = Path(__file__).resolve().parent / "static"
UPLOAD_DIR = Path(os.environ.get("PORTAL_UPLOAD_DIR", Path(tempfile.gettempdir()) / "portal-uploads"))
ALLOWED = {".pdf", ".txt", ".md"}
MAX_BYTES = 20 * 1024 * 1024


def pick_brain():
    """Real Claude if configured, otherwise the offline demo brain."""
    if os.environ.get("BEDROCK_MODEL_ID") and os.environ.get("PORTAL_BRAIN", "").lower() != "demo":
        from agent.llm import BedrockLLM
        return BedrockLLM(), "Claude on Amazon Bedrock"
    return DemoLLM(), DemoLLM.name


class AgentRunner:
    """Runs the (async) agent on its own background thread so Flask's normal (blocking) code can use it."""

    def __init__(self):
        self.loop = asyncio.new_event_loop()
        threading.Thread(target=self.loop.run_forever, daemon=True, name="agent-loop").start()
        self.brain, self.brain_name = pick_brain()
        self.agent: PortalAgent | None = None
        self._lock: asyncio.Lock | None = None

    def _run(self, coro, timeout):
        return asyncio.run_coroutine_threadsafe(coro, self.loop).result(timeout)

    def start(self) -> None:
        async def boot():
            self._lock = asyncio.Lock()
            self.agent = PortalAgent(self.brain)
            await self.agent.__aenter__()
        self._run(boot(), 180)
        log.warning("Portal ready: %d tools, brain=%s, unavailable=%s", len(self.agent.tools), self.brain_name, list(self.agent.unavailable))

    def ask(self, question: str):
        async def go():
            async with self._lock:  # one question at a time keeps the chat history in order
                return await self.agent.ask(question)
        return self._run(go(), 180)

    def reset(self) -> None:
        self.agent.reset()

    def call_tool(self, name: str, args: dict) -> dict:
        async def go():
            res = await self.agent.sessions[name].call_tool(name, args)
            text = "".join(getattr(c, "text", "") for c in res.content)
            if getattr(res, "isError", False) or getattr(res, "is_error", False):
                raise RuntimeError(text)
            return json.loads(text)
        return self._run(go(), 120)


def create_app(runner: AgentRunner | None = None) -> Flask:
    app = Flask(__name__, static_folder=None)
    app.config["MAX_CONTENT_LENGTH"] = MAX_BYTES + 1024 * 64
    app.config["RUNNER"] = runner or AgentRunner()
    if runner is None:
        app.config["RUNNER"].start()
    run: AgentRunner = app.config["RUNNER"]

    @app.get("/")
    def index():
        return send_from_directory(STATIC, "index.html")

    @app.get("/api/health")
    def health():
        a = run.agent
        return jsonify(ok=True, brain=run.brain_name, tools=len(a.tools), unavailable=list(a.unavailable))

    @app.post("/api/ask")
    def ask():
        q = ((request.get_json(silent=True) or {}).get("question") or "").strip()
        if not q:
            return jsonify(error="Type or say a question first."), 400
        if len(q) > 1000:
            return jsonify(error="That question is too long (max 1000 characters)."), 400
        try:
            r = run.ask(q)
        except Exception as exc:  # noqa: BLE001
            log.exception("ask failed")
            return jsonify(error=f"Portal hit a problem: {exc}"), 500
        return jsonify(answer=r.answer, trace=r.trace, brain=run.brain_name)

    @app.post("/api/briefing")
    def briefing():
        r = run.ask("Give me my morning briefing: my classes today, any attendance warnings, anything due soon, "
                    "and what I need in my next internal.")
        return jsonify(answer=r.answer, trace=r.trace, brain=run.brain_name)

    @app.post("/api/reset")
    def reset():
        run.reset()
        return jsonify(ok=True)

    @app.post("/api/upload")
    def upload():
        f = request.files.get("file")
        subject, module = (request.form.get("subject") or "").strip(), (request.form.get("module") or "").strip()
        if not f or not f.filename:
            return jsonify(error="Choose a file first."), 400
        if not subject or not module:
            return jsonify(error="Fill in the subject and the module, e.g. Maths and Module 1."), 400
        name = secure_filename(f.filename)
        if Path(name).suffix.lower() not in ALLOWED:
            return jsonify(error="Only PDF, TXT or MD files, please."), 400
        UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
        dest = UPLOAD_DIR / name
        f.save(dest)
        try:
            out = run.call_tool("save_note", {"subject": subject, "module": module, "file_path": str(dest)})
        except Exception as exc:  # noqa: BLE001
            return jsonify(error=f"Couldn't save that: {exc}"), 400
        return jsonify(saved=out["saved"])

    return app


if __name__ == "__main__":
    logging.basicConfig(level=logging.WARNING)
    create_app().run(host=os.environ.get("PORTAL_HOST", "127.0.0.1"), port=int(os.environ.get("PORTAL_PORT", "8000")), threaded=True)
